/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/

#ifndef ForensicDOMEvent_h
#define ForensicDOMEvent_h

//Base class for DOM event

#include "core/inspector/forensics/ForensicPageEvent.h"
#include "core/frame/Frame.h"



namespace blink {

class ForensicEventVisitor;
class ForensicReplayEngine;
class Document;
class Node;
class LocalFrame;

class ForensicDOMEvent : public ForensicPageEvent {

public:

    virtual ~ForensicDOMEvent(){};
    virtual String getStringRef() = 0;
    virtual Node* getSelfNode() =0;
    virtual Node* getParentNode() =0;
    virtual String getNodeSource() = 0;
    virtual bool isRewrite() =0;
    virtual bool run(PassRefPtr<ForensicReplayEngine>  engine, LocalFrame* frame) = 0;
    virtual bool isDOMEventReplayable(PassRefPtr<ForensicReplayEngine>  engine, LocalFrame* frame) = 0;
    virtual bool isDelayedReplayNeeded() =0;
    virtual void runNoDelayActions(PassRefPtr<ForensicReplayEngine>  engine, LocalFrame* frame) =0;
    virtual String getNodeValue() {return String();}
	void setFrame(Frame* frame){m_frame = frame;}
	Frame* getFrame(){return m_frame;}
	void setIsActiveNextHandler(bool isActiveNextHandler){ m_isActiveNextHandler = isActiveNextHandler;}
	bool isActiveNextHandler(){return m_isActiveNextHandler;}
	
protected:
    ForensicDOMEvent(const KURL& pageURL, double timeStampMs);

private:
	Frame* m_frame;
	bool m_isActiveNextHandler;

}; // class ForensicDOMEvent

} // namespace blink

#endif /* ForensicDOMEvent_h */