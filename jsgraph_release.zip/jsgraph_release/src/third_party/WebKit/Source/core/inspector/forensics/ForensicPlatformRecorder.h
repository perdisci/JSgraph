/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/

#ifndef ForensicPlatformRecorder_h
#define ForensicPlatformRecorder_h

#include "core/inspector/forensics/ForensicPlatformWrapper.h"
#include "core/inspector/forensics/ForensicDataStore.h"
#include "wtf/PassRefPtr.h"
#include "wtf/RefCounted.h"

namespace blink {

class WebURLLoader;

class ForensicPlatformRecorder : public ForensicPlatformWrapper, public RefCounted<ForensicPlatformRecorder> {

public:

    static PassRefPtr<ForensicPlatformRecorder> create(Platform* blinkPlatform, PassRefPtr<ForensicDataStore> dataStore);
    ~ForensicPlatformRecorder();

    WebURLLoader* createURLLoader() override;
    WebCookieJar* cookieJar() override;

private:

    BLINK_PLATFORM_EXPORT ForensicPlatformRecorder(Platform* blinkPlatform, PassRefPtr<ForensicDataStore> dataStore);     

    RefPtr<ForensicDataStore> m_dataStore;

};

} // namespace blink

#endif // ForensicPlatformRecorder_h
