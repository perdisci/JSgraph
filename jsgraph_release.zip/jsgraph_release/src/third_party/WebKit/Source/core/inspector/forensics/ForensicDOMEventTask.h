#ifndef ForensicDOMEventTask_h
#define ForensicDOMEventTask_h


#include "core/inspector/forensics/ForensicDOMEvent.h"
#include "public/platform/WebTaskRunner.h"
#include "wtf/PassRefPtr.h"

namespace blink {

class ForensicReplayEngine;

class ForensicDOMEventTask : public WebTaskRunner::Task {

public:

    ForensicDOMEventTask(PassRefPtr<ForensicDOMEvent> event, PassRefPtr<ForensicReplayEngine> engine, LocalFrame* frame);
    virtual ~ForensicDOMEventTask() {};
    
    virtual void run() override;

private:

    RefPtr<ForensicReplayEngine> m_engine;
    RefPtr<ForensicDOMEvent> m_event;
    LocalFrame* m_frame;


}; // ForensicDOMEventTask

} // namespace blink

#endif // ForensicDOMEventTask_h