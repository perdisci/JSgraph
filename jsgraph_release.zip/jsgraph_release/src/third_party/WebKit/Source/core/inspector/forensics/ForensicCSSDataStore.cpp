#include "config.h"
#include "core/inspector/forensics/ForensicCSSDataStore.h"
#include "platform/Logging.h"




namespace blink {

PassRefPtr<ForensicCSSDataStore> ForensicCSSDataStore::create(unsigned i, const String& data){
	
	return adoptRef(new ForensicCSSDataStore(i, data));
}


unsigned ForensicCSSDataStore::getIntDataStore(){
	return m_intDataStore;
}

String ForensicCSSDataStore::getStringDataStore(){
	return m_stringDataStore;
}

ForensicCSSDataStore::ForensicCSSDataStore(unsigned i, const String& data)
: m_intDataStore(i)
, m_stringDataStore(data)
{
	WTF_LOG(Forensics,"ForensicCSSDataStore::ForensicCSSDataStore: recorded. intdata: %d, data: %s. ", i, data.latin1().data());

}

} // namespace blink