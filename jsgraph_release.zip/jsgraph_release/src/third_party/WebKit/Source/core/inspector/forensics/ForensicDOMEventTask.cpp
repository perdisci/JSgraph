#include "config.h"
#include "core/inspector/forensics/ForensicReplayEngine.h"
#include "core/inspector/forensics/ForensicDOMEventTask.h"

namespace blink {

ForensicDOMEventTask::ForensicDOMEventTask(PassRefPtr<ForensicDOMEvent> event, PassRefPtr<ForensicReplayEngine> engine, LocalFrame* frame)
    : m_engine(engine)
    , m_event(event) 
    , m_frame(frame)
{
}

void ForensicDOMEventTask::run() {
    m_event->run(m_engine,m_frame);
}

} // namespace blink
