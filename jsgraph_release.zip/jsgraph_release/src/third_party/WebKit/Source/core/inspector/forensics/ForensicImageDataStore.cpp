/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/

#include "config.h"
#include "core/inspector/forensics/ForensicImageDataStore.h"
#include "platform/weborigin/KURL.h"
#include "core/html/HTMLImageElement.h"
#include "core/fetch/ImageResource.h"
#include "core/dom/Node.h"
#include "core/dom/Document.h"
#include "core/dom/Element.h"
#include "core/editing/serializers/Serialization.h"
#include "platform/Logging.h"
#include "wtf/text/WTFString.h"
#include "platform/graphics/Image.h"


namespace blink {


PassRefPtr<ForensicImageDataStore> ForensicImageDataStore::create(Document* document, Node* node){
    return adoptRef(new ForensicImageDataStore(document, node));
}

ForensicImageDataStore::ForensicImageDataStore(Document* document, Node* node)
{
        //To be released
}

PassRefPtr<SharedBuffer>  ForensicImageDataStore::getImageData(){
        return m_imageData;
}

const KURL& ForensicImageDataStore::getImageSrc(){
        return m_imageSrc;
}


} // namespace blink
