/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/

#include "config.h"

#include <v8.h>
#include "core/inspector/InspectorForensicsAgent.h"
#include "core/inspector/forensics/Forensics.h"
#include "wtf/PassRefPtr.h"
#include "wtf/PassOwnPtr.h"
#include "platform/TraceEvent.h"
#include "core/inspector/InspectorState.h"
#include "core/inspector/InspectorPageAgent.h"
#include "core/html/HTMLHeadElement.h"
#include "core/dom/Node.h"
#include "core/dom/Document.h"
#include "core/page/Page.h"
#include "core/frame/LocalFrame.h"
#include "platform/Logging.h"
#include "public/web/WebInputEvent.h"
//#include "core/inspector/forensics/ForensicInputEvent.h"
//#include "core/inspector/forensics/ForensicLoadURLEvent.h"
#include "core/html/HTMLImageElement.h"
#include "bindings/core/v8/ScriptEventListener.h"
#include "core/events/Event.h"
#include "core/events/EventTarget.h"
#include "core/editing/serializers/Serialization.h"
#include "bindings/core/v8/ScheduledAction.h"
#include "core/dom/ExecutionContext.h"
//#include "core/inspector/forensics/ForensicXHRDataStore.h"
#include "core/layout/LayoutView.h"
#include "core/layout/LayoutPart.h"
#include "platform/text/SegmentedString.h"
#include "core/dom/CharacterData.h"
#include "core/dom/FrameRequestCallback.h"
#include "core/html/HTMLFormElement.h"
#include "wtf/HashSet.h"
#include <sstream>

//Phani
#include "public/platform/WebFileUtilities.h"
//Phani

#define NUMBER_TO_STRING_DECIMAL_DIGITS 6

namespace blink {

InspectorForensicsAgent::InspectorForensicsAgent(LocalFrame* inspectedFrame, InspectorPageAgent* pageAgent)
    : InspectorBaseAgent<InspectorForensicsAgent, InspectorFrontend::Forensics>("Forensics")
    , m_inJSCounter(0)
    , m_pageAgent(pageAgent)
    , m_inspectedFrame(inspectedFrame)
    , m_blinkPlatform(Platform::current())
{
    ASSERT(inspectedFrame);
    ASSERT(pageAgent);

	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::InspectorForensicsAgent : Initializing Forensics Agent : Inspected Frame URL = ", Forensics::getCurrentURLCString(inspectedFrame).data());
    resetAgentState();
    createDataStore();
    enableJavaScript();
    disableAsynchronousParsing();
    //LocalDOMWindow * domWindow = inspectedFrame->localFrameRoot()->localDOMWindow();
    m_blinkPlatform->suddenTerminationChanged(false);
}

InspectorForensicsAgent::~InspectorForensicsAgent()
{
}


// Agent Control

void InspectorForensicsAgent::innerEnable()
{
    resetAgentState();
    m_mainFrame = m_inspectedFrame->localFrameRoot();
    m_document = m_pageAgent->inspectedFrame()->document();

    m_state->setBoolean(ForensicsAgentState::forensicsAgentEnabled, true);
    m_instrumentingAgents->setInspectorForensicsAgent(this);
}

void InspectorForensicsAgent::enable(ErrorString*)
{
	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::enable : Enabling Forensics Agent");
    if (enabled())
        return;
    innerEnable();
}

void InspectorForensicsAgent::restore()
{
    if (!enabled())
        return;
    innerEnable();
}

bool InspectorForensicsAgent::enabled() const
{
    return m_state->getBoolean(ForensicsAgentState::forensicsAgentEnabled);
}

void InspectorForensicsAgent::disable(ErrorString* errorString)
{
	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::disable : Disabling Forensics Agent");

    if (!enabled()) {
        if (errorString)
            *errorString = "Forensics agent hasn't been enabled";
        return;
    }
    m_state->setBoolean(ForensicsAgentState::forensicsAgentEnabled, false);
    m_instrumentingAgents->setInspectorForensicsAgent(nullptr);
    m_document = nullptr;
}


void InspectorForensicsAgent::createDataStore() {
    m_dataStore = ForensicDataStore::create();
    m_dataStore->setBlinkPlatform(m_blinkPlatform);
}


void InspectorForensicsAgent::resetAgentState() {
    m_recording = false;
    m_replaying = false;
    Forensics::s_isBlockNetworkRequest = false; //NOTE(Bo): this is a temp solution, will be removed later
    Forensics::s_isInstallDomTimer = true;
    Forensics::s_isRunWebWorker = true;
    Forensics::s_isSendXMLRequest = true;
    Forensics::s_isSetWeakCallback = true;
    m_scriptId2HashMap.clear();
    
}

void InspectorForensicsAgent::wrapPlatformForRecording() {
    m_forensicPlatformRecorder = ForensicPlatformRecorder::create(m_blinkPlatform, m_dataStore);
    Platform::initialize(m_forensicPlatformRecorder.get());
}

void InspectorForensicsAgent::unwrapPlatformAfterRecording() {
    Platform::initialize(m_blinkPlatform);
    m_forensicPlatformRecorder = nullptr;
}


// Commands
void InspectorForensicsAgent::startRecording(ErrorString* error) {
    if(recording())
        return;

    enable(error);
    if(!error->isEmpty()) {
        m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::startRecording : unable to enable agent (",Forensics::toCString(error).data(),")");
        return;
    }

    // wrap Blink's Platform
    wrapPlatformForRecording();
    resetAgentState();
    m_initialPageURL = Forensics::getCurrentURL(m_mainFrame);
    //Load a blank page to avoid recording extra events.
    ForensicReplayEngine::doCleanCacheAndReloadPage(m_mainFrame, KURL(ParsedURLString, "about:blank"));
    m_recording = true;
    Forensics::s_isBlockNetworkRequest = false; //NOTE(Bo): this is a temp solution, will be removed later
    Forensics::s_isInstallDomTimer = true;
    Forensics::s_isRunWebWorker = true;
    Forensics::s_isSendXMLRequest = true;
    Forensics::s_isSetWeakCallback = true;
    m_recordingStartTime = Forensics::getCurrentTimeMs();
    v8::V8::StartPlatformInstRecording();
    
	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::startRecording");

	TRACE_EVENT_BEGIN0("jsgraph", "JSCapsule::InspectorForensicsAgent::Recording");

    // clearn cache and reload initial page
    ForensicReplayEngine::doCleanCacheAndReloadPage(m_mainFrame, m_initialPageURL);

}

void InspectorForensicsAgent::stopRecording(ErrorString* error) {
    if(!recording())
        return;
        
    unwrapPlatformAfterRecording();
    resetAgentState();
    disable(error);
    v8::V8::StopPlatformInst();
    m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::stopRecording");
    TRACE_EVENT_END0("jsgraph", "JSCapsule::InspectorForensicsAgent::Recording");
}

bool InspectorForensicsAgent::recording() {
    return m_recording;
}


void InspectorForensicsAgent::startReplay(ErrorString* error) {
//TO BE RELEASED
}

void InspectorForensicsAgent::stopReplay(ErrorString* error) {
//TO BE RELEASED
}

bool InspectorForensicsAgent::replaying() {
    return m_replaying;
}


void InspectorForensicsAgent::enableAsynchronousParsing() {
    Forensics::setIsAsynchronousParsingAllowed(true);
    m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::enableAsynchronousParsing : enabled = ", std::to_string(Forensics::isAsynchronousParsingAllowed()));
}

void InspectorForensicsAgent::enableAsynchronousParsing(ErrorString* error) {
    enableAsynchronousParsing();
}

void InspectorForensicsAgent::disableAsynchronousParsing() {
    Forensics::setIsAsynchronousParsingAllowed(false);
    m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::disableAsynchronousParsing : enabled = ", std::to_string(Forensics::isAsynchronousParsingAllowed()));
}

void InspectorForensicsAgent::disableAsynchronousParsing(ErrorString* error) {
    disableAsynchronousParsing();
}


void InspectorForensicsAgent::enableTakeDOMTextSnapshot() {
    Forensics::setIsTakeDOMTextSnapshotAllowed(true);
    m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::enableTakeDOMTextSnapshot : enabled = ", std::to_string(Forensics::isTakeDOMTextSnapshotAllowed()));
}

void InspectorForensicsAgent::enableTakeDOMTextSnapshot(ErrorString* error) {
    enableTakeDOMTextSnapshot();
}

void InspectorForensicsAgent::disableTakeDOMTextSnapshot() {
    Forensics::setIsTakeDOMTextSnapshotAllowed(false);
    m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::disableTakeDOMTextSnapshot : enabled = ", std::to_string(Forensics::isTakeDOMTextSnapshotAllowed()));
}

void InspectorForensicsAgent::disableTakeDOMTextSnapshot(ErrorString* error) {
    disableTakeDOMTextSnapshot();
}


void InspectorForensicsAgent::enableJavaScript() {
    Forensics::setIsJavaScriptAllowed(true);
	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::enableJavaScript : enabled = ", std::to_string(Forensics::isJavaScriptAllowed()));
}

void InspectorForensicsAgent::enableJavaScript(ErrorString* error) {
    enableJavaScript();
}

void InspectorForensicsAgent::disableJavaScript() {
    Forensics::setIsJavaScriptAllowed(false);
    m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::disableJavaScript : enabled = ", std::to_string(Forensics::isJavaScriptAllowed()));
}

void InspectorForensicsAgent::disableJavaScript(ErrorString* error) {
    disableJavaScript();
}


// Hooks
void InspectorForensicsAgent::willHandleEvent(EventTarget* eventTarget, Event* event, EventListener* listener, bool useCapture){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::willHandleEvent");

    if (m_recording){

    	if(m_inJSCounter==0){
			m_dataStore->recordFireEventListenerEvent(m_mainFrame, eventTarget, event, listener, useCapture, true);
		}
    }
}

void InspectorForensicsAgent::willSendXMLHttpRequest(const String& url){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::willSendXMLHttpRequest");
	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::willSendXMLHttpRequest URL: ", url.latin1().data());
}

void InspectorForensicsAgent::didInsertDOMNode(Node* node){
}

void InspectorForensicsAgent::didInsertDOMNodeForensics(Node* node){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::didInsertDOMNodeForensics");

    if (m_recording){

            m_dataStore->recordInsertDOMNodeEvent(&(node->document()), node);

    }

}

void InspectorForensicsAgent::characterDataModified(CharacterData* textnode){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::characterDataModified");
	Node* node = textnode;
	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::characterDataModified: m_selfNode: ",std::to_string((long) node),", node: ", node->nodeValue().latin1().data());
}

void InspectorForensicsAgent::handleCharacterDataPaserAppendDataForensics(CharacterData* node, const String& data){

}

void InspectorForensicsAgent::willRemoveDOMNode(Node* node){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::willRemoveDOMNode");
	if(m_inJSCounter>0){
		if(m_recording){
			m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::willRemoveDOMNode: m_selfNode: ", std::to_string((long) node));
		}
	}
}

void InspectorForensicsAgent::willModifyDOMAttrForensics(Element* element, const QualifiedName& name, const AtomicString& Value){

}


void InspectorForensicsAgent::didModifyDOMAttr(Element* element, const QualifiedName& name, const AtomicString& value){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::didModifyDOMAttr");
	if(m_inJSCounter>0){
		if(m_recording){
			m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::didModifyDOMAttr: m_selfNode: ",std::to_string((long) element),", m_nodeSource: ", Forensics::CreateMarkupWithoutChildren(element).latin1().data());
		}

	}
}

void InspectorForensicsAgent::didRemoveDOMAttr(Element* element, const QualifiedName& name){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::didRemoveDOMAttr");
	if(m_inJSCounter>0){
		if(m_recording){
			m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::didRemoveDOMAttr: m_selfNode: ",std::to_string((long) element),",  m_nodeSource: ", Forensics::CreateMarkupWithoutChildren(element).latin1().data());
		}
	}
}

void InspectorForensicsAgent::didInvalidateStyleAttr(Node* node){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::didInvalidateStyleAttr");

	if(m_inJSCounter>0){
		if(m_recording){
			RefPtr<CSSValue> css_value = node->isElementNode()?toElement(node)->style()->getPropertyCSSValueInternal(CSSPropertyBackgroundImage):nullptr;
			if (css_value && css_value->isImageValue()) {
    			CSSImageValue * image_value = toCSSImageValue(css_value.get());
    			String url = image_value->url();
    			int hash = StringHash::hash(url);
    			if (!m_node2BackgroundImageHashMap.contains((long) node)){
    				//first time, output with image data
    				m_node2BackgroundImageHashMap.add((long) node, hash);
    				m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::didInvalidateStyleAttr: m_selfNode: ",std::to_string((long) node), ",  m_nodeSource: ", Forensics::CreateMarkupWithoutChildren(node).latin1().data());
    			}
    			else{
    				if (m_node2BackgroundImageHashMap.get((long) node)==hash){
    					//output without image data
    					Forensics::s_isOutputBackgroundImage=false;
    					m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::didInvalidateStyleAttr: m_selfNode: ",std::to_string((long) node),",  m_nodeSource: ", Forensics::CreateMarkupWithoutChildren(node).latin1().data());
    					Forensics::s_isOutputBackgroundImage=true;

    				}
    				else{
    					//output with image data
    					m_node2BackgroundImageHashMap.set((long) node, hash);
    					m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::didInvalidateStyleAttr: m_selfNode: ",std::to_string((long) node),",  m_nodeSource: ", Forensics::CreateMarkupWithoutChildren(node).latin1().data());
    				}
    			}
    							
    		}

    		else{
    			m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::didInvalidateStyleAttr: m_selfNode: ",std::to_string((long) node),",  m_nodeSource: ",  Forensics::CreateMarkupWithoutChildren(node).latin1().data());
    		}
		}

	}
}

void InspectorForensicsAgent::didPushShadowRoot(Element* host, ShadowRoot* shadow){
}

void InspectorForensicsAgent::frameAttachedToParent(LocalFrame* frame){
}

void InspectorForensicsAgent::didStartProvisionalLoadForensics(LocalFrame* frame, const KURL& requestURL){
    if (frame==m_mainFrame){

    	
    	RefPtr<TracedValue> value = TracedValue::create();
		value->setString("url", requestURL.string());
    	
    	TRACE_EVENT_BEGIN1("jsgraph", "JSCapsule::InspectorForensicsAgent::didStartProvisionalLoadForensics", "url", value.release());
		TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::didStartProvisionalLoadForensics");
		
    	if (m_recording){
            m_dataStore->recordPageLoadEvent(frame, requestURL);
    	}

    }
}

void InspectorForensicsAgent::receivedMainResourceRedirectForensics(LocalFrame* frame, const KURL& newURL){
	if (frame==m_mainFrame){
		TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::receivedMainResourceRedirectForensics");
		if (m_recording){
			m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::receivedMainResourceRedirectForensics : frame: ",std::to_string((long) frame),", new_URL: ", newURL.string().latin1().data());
		}
	}
}

void InspectorForensicsAgent::handleInputEventForensics(LocalFrame* mainFrame, const WebInputEvent& inputEvent) 
{

}

void InspectorForensicsAgent::handleRunCompiledScriptStartForensics(ExecutionContext* context, int scriptId, bool& m_enableJaveScript)
{
	if (m_inJSCounter==0){
		TRACE_EVENT_END0("jsgraph", "JSCapsule::InspectorForensicsAgent::OutSideJSTime");
	}
	TRACE_EVENT_BEGIN0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRunCompiledScriptForensics");
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRunCompiledScriptStartForensics");
    m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRunCompiledScriptStartForensics Thread_id:",std::to_string((long)WTF::currentThread),", iframe: ",std::to_string((long) context->executingWindow()->frame()),",Script_id: ", std::to_string(scriptId));

	
    m_enableJaveScript = Forensics::isJavaScriptAllowed();
    m_inJSCounter++;
}

void InspectorForensicsAgent::handleRunCompiledScriptEndForensics(int scriptId)
{
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRunCompiledScriptEndForensics");
    m_inJSCounter--;
    m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRunCompiledScriptEndForensics Thread_id:",std::to_string((long)WTF::currentThread)," Script_id: ", std::to_string(scriptId));
    TRACE_EVENT_END0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRunCompiledScriptForensics");
    if (m_inJSCounter==0){
		TRACE_EVENT_BEGIN0("jsgraph", "JSCapsule::InspectorForensicsAgent::OutSideJSTime");
	}
}

void InspectorForensicsAgent::handleCompileScriptForensics(v8::Local<v8::String> code, int scriptId, const KURL& url, const TextPosition& startposition)
{
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleCompileScriptForensics");
    const String& code_string = String(V8StringResource<>(code));
    m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleCompileScriptForensics  Thread_id:",std::to_string((long)WTF::currentThread),", Script_id:",std::to_string(scriptId),", URL: ",url.string().latin1().data(),", line: ",std::to_string(startposition.m_line.zeroBasedInt()),", column: ",std::to_string(startposition.m_column.zeroBasedInt()),", Source: \n ",code_string.latin1().data()," \n");
}

void InspectorForensicsAgent::handleCallFunctionStartForensics(ExecutionContext* context, v8::MaybeLocal<v8::Function> Function, bool& m_enableJavaScript)
{
	if (m_inJSCounter==0){
		TRACE_EVENT_END0("jsgraph", "JSCapsule::InspectorForensicsAgent::OutSideJSTime");
	}
	TRACE_EVENT_BEGIN0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleCallFunctionForensics");
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleCallFunctionStartForensics");
 
    v8::Local<v8::Function> function;
    bool sucess = Function.ToLocal(&function);
    if (sucess)
    {
          //avoid used warning
    }

    if (function->IsBuiltin())
    {
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleCallFunctionStartForensics Thread_id:",std::to_string((long)WTF::currentThread),"  function_id:",std::to_string(function->ScriptId()),";  Name: Builtin; line:",std::to_string(function->GetScriptLineNumber()),"; column: ", std::to_string(function->GetScriptColumnNumber()) );
    }
    else
    {
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleCallFunctionStartForensics Thread_id:",std::to_string((long)WTF::currentThread)," function_id:",std::to_string(function->ScriptId()),"; Name:",String(V8StringResource<>(function->GetName())).latin1().data(),"; line:",std::to_string(function->GetScriptLineNumber()),"; column: ", std::to_string(function->GetScriptColumnNumber()));

    }
    m_enableJavaScript = Forensics::isJavaScriptAllowed();
    m_inJSCounter++;
}

void InspectorForensicsAgent::handleCallFunctionEndForensics(v8::MaybeLocal<v8::Function> Function)
{
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleCallFunctionEndForensics");
    v8::Local<v8::Function> function;
    bool sucess = Function.ToLocal(&function);
    if (sucess)
    {
          //avoid used warning
    }

    if (function->IsBuiltin())
    {
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleCallFunctionEndForensics Thread_id:",std::to_string((long)WTF::currentThread),"  function_id:",std::to_string(function->ScriptId()),";  Name: Builtin; line:",std::to_string(function->GetScriptLineNumber()),"; column: ", std::to_string(function->GetScriptColumnNumber()) );
    }
    else
    {
    	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleCallFunctionEndForensics Thread_id:",std::to_string((long)WTF::currentThread)," function_id:",std::to_string(function->ScriptId()),"; Name:",String(V8StringResource<>(function->GetName())).latin1().data(),"; line:",std::to_string(function->GetScriptLineNumber()),"; column: ", std::to_string(function->GetScriptColumnNumber()) );

    }
    m_inJSCounter--;

    TRACE_EVENT_END0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleCallFunctionForensics");
    if (m_inJSCounter==0){
		TRACE_EVENT_BEGIN0("jsgraph", "JSCapsule::InspectorForensicsAgent::OutSideJSTime");
	}
}

void InspectorForensicsAgent::handleGetElementByIdForensics(Node* node){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleGetElementByIdForensics");
    if (m_recording){
        if (m_inJSCounter>0 && isHTMLImageElement(node)) {
            m_dataStore->recordImage(m_document.get(), node);
        }
    }
}

bool InspectorForensicsAgent::handleCreateChildFrameLoaderForensics(LocalFrame* frame, const KURL& url){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleCreateChildFrameLoaderForensics");

    if (m_recording){
    	m_dataStore->recordChildFrame(frame, url);
    	return false;
    }
    return false;
}

void InspectorForensicsAgent::handleCreateChildFrameLoaderEndForensics(LocalFrame* frame, const KURL& url){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleCreateChildFrameLoaderEndForensics");
	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleCreateChildFrameLoaderEndForensics");
}

bool InspectorForensicsAgent::handleAddEventListenerForensics(EventTarget* eventTarget, const AtomicString& eventType, PassRefPtr<EventListener> listener, bool useCapture){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleAddEventListenerForensics");
		if (m_recording){
			m_dataStore->recordAddEventListenerEvent(eventTarget, listener.get());
			if(m_inJSCounter==0){
				m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleAddEventListenerForensics: frame: ", std::to_string((long) (eventTarget->toNode()? eventTarget->toNode()->document().frame(): (eventTarget->toDOMWindow()?eventTarget->toDOMWindow()->frame():m_mainFrame.get()))));
			}
		}
	return false;
}

int InspectorForensicsAgent::handleDOMTimerInstallEventReplay(ExecutionContext* context, PassOwnPtr<ScheduledAction> action){

}

void InspectorForensicsAgent::handleDOMTimerInstallEventRecording(ExecutionContext* context, ScheduledAction* action, int timeoutID){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleDOMTimerInstallEventRecording");
	if (m_recording){
		m_dataStore->recordInstallDOMTimerEvent(context, action, timeoutID);
	}
}

void InspectorForensicsAgent::handlewillFireTimerEvent(ExecutionContext* context, ScheduledAction* action, int  timeoutID, bool singleShot){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handlewillFireTimerEvent");
	if(m_recording){
		m_dataStore->recordFireDOMTimerEvent(m_mainFrame, context, action, timeoutID,  singleShot);
	}
}

bool InspectorForensicsAgent::handleRegisterFrameRequestCallbackForensics(FrameRequestCallback*  callback, int& id){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRegisterFrameRequestCallbackForensics");
	if (m_recording){
		m_dataStore->recordRegisterFrameRequestCallbackEvent(callback, id);
	}
	return false;
}
void InspectorForensicsAgent::handlExecuteFrameRequestCallbackEventForensics(ExecutionContext* context, FrameRequestCallback*  callback, int id, double highResNowMs){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handlExecuteFrameRequestCallbackEventForensics");
	if (m_recording){
		m_dataStore->recordExecuteFrameRequestCallbackEvent(context, callback, id, highResNowMs);
	}
}

bool InspectorForensicsAgent::handleGetXHRDataStatusForensics(int& data){

	return false;
}
bool InspectorForensicsAgent::handleGetXHRDataReadyStateForensics(int& data){

	return false;
}
bool InspectorForensicsAgent::handleGetXHRDataResponseTextForensics(ScriptString& data){

	return false;
}

bool InspectorForensicsAgent::handleGetXHRDataOpenForensics(bool& data){

	return false;
}

bool InspectorForensicsAgent::handleGetXHRDataResponseTypeCodeForensics(int& data){

	return false;
}

void InspectorForensicsAgent::handleRecordXHRDataStatusForensics(int data){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordXHRDataStatusForensics");
	if(m_recording && m_inJSCounter>0){
		m_dataStore->recordXHRDataStore(ForensicXHRDataStore::create(data));
	}
}
void InspectorForensicsAgent::handleRecordXHRDataReadyStateForensics(int data){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordXHRDataReadyStateForensics");
	if(m_recording && m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRecordXHRDataReadyStateForensics: ReadyState: ", std::to_string(data));
	}
}
void InspectorForensicsAgent::handleRecordXHRDataResponseTextForensics(ScriptString data){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordXHRDataResponseTextForensics");
	if(m_recording && m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRecordXHRDataResponseTextForensics: ResponseText: ", data.flattenToString().latin1().data());

	}
}

void InspectorForensicsAgent::handleRecordXHRDataOpenForensics(bool data){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordXHRDataOpenForensics");
	if(m_recording && m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRecordXHRDataOpenForensics: OPENED: ", std::to_string(data));
	}
}

void InspectorForensicsAgent::handleRecordXHRDataResponseTypeCodeForensics(int data){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordXHRDataResponseTypeCodeForensics");
	if(m_recording && m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRecordXHRDataResponseTypeCodeForensics: ResponseTypeCode: ", std::to_string(data));
	}
}

void InspectorForensicsAgent::handleRecordXHRSetRequestHeaderForensics(const AtomicString& name, const AtomicString& value){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordXHRSetRequestHeaderForensics");
	if(m_recording && m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRecordXHRSetRequestHeaderForensics: Name: ",String(name).latin1().data(),", Value: ", String(value).latin1().data());
	}
}

void InspectorForensicsAgent::handleEvaluateScriptInMainWorldForensics(ExecutionContext* context, const ScriptSourceCode&  sourceCode, int accessControlStatus, bool policy){

}

void InspectorForensicsAgent::handleRecordCookieForensics(LocalFrame*, const String& cookieString, const String& exceptionStateString){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordCookieForensics");
	if(m_recording && m_inJSCounter>0){
		m_dataStore->recordCookieDataStore(cookieString, exceptionStateString);
	}
}
bool InspectorForensicsAgent::handleGetCookieForensics(LocalFrame*, String& cookieString, String& exceptionStateString){
	return false;
}
void InspectorForensicsAgent::handleRecordSetCookieForensics(LocalFrame*, const String& exceptionStateString){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordSetCookieForensics");
	if(m_recording && m_inJSCounter>0){
		m_dataStore->recordSetCookieDataStore(exceptionStateString);
	}
}
bool InspectorForensicsAgent::handleGetSetCookieForensics(LocalFrame*, String& exceptionStateString){

	return false;
}

bool InspectorForensicsAgent::handleDocumentWriteStart(LocalFrame*, bool& hasInsertionPoint, const SegmentedString& text){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleDocumentWriteStart");
	m_inDocumentWriteCounter++;
	if(m_recording){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleDocumentWriteStart: Replaying, text: ", text.toString().latin1().data());
		m_dataStore->recordDocumentWriteDataStore(hasInsertionPoint);
	}
	return false;
}
void InspectorForensicsAgent::handleDocumentWriteEnd(LocalFrame*, bool hasInsertionPoint){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleDocumentWriteEnd");
	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleDocumentWriteEnd");
	m_inDocumentWriteCounter--;
}

bool InspectorForensicsAgent::handleDynamicScriptExecutionStartForensics(Element* element){
	return false;
}

void InspectorForensicsAgent::handleDynamicScriptExecutionEndForensics(Element* element){

}


bool InspectorForensicsAgent::handleDocumentReadyStateReplaying(String& readyState){

	return false;
}
void InspectorForensicsAgent::handleDocumentReadyStateRecording(const String& readyState){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleDocumentReadyStateRecording");
	if(m_recording && m_inJSCounter>0){
		m_dataStore->recordDocumentReadyState(readyState);
	}
}

bool InspectorForensicsAgent::handleGetCSSItemForensics(unsigned i, String& data){

	return false;
}

void InspectorForensicsAgent::handleSetCSSItemForensics(unsigned i, const String& data){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleSetCSSItemForensics");
	if(m_recording&& m_inJSCounter>0){
		m_dataStore->recordCSSDataStore(ForensicCSSDataStore::create(i, data));
	}
}

void InspectorForensicsAgent::handleSetCSSLengthForensics(unsigned length){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleSetCSSLengthForensics");
	if(m_recording&& m_inJSCounter>0){
		m_dataStore->recordCSSDataStore(ForensicCSSDataStore::create(length, String()));
	}
}
bool InspectorForensicsAgent::handleGetCSSLengthForensics(unsigned& length){

	return false;
}

void InspectorForensicsAgent::handleSetCSSGetPropertyValueForensics(const String& data){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleSetCSSGetPropertyValueForensics");
	if(m_recording&& m_inJSCounter>0){
		m_dataStore->recordCSSDataStore(ForensicCSSDataStore::create(0, data));
	}
}
bool InspectorForensicsAgent::handleGetCSSGetPropertyValueForensics(String& data){

	return false;
}

void InspectorForensicsAgent::handleSetCSSGetPropertyPriorityForensics(const String& data){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleSetCSSGetPropertyPriorityForensics");
	if(m_recording&& m_inJSCounter>0){
		m_dataStore->recordCSSDataStore(ForensicCSSDataStore::create(0, data));
	}
}

void InspectorForensicsAgent::handleScrollIntoViewIfNeededForensics(Element* element, bool centerIfNeeded){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleScrollIntoViewIfNeededForensics");
	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleScrollIntoViewIfNeededForensics : Element: ",std::to_string((long) element),", centerIfNeeded: ", std::to_string(centerIfNeeded));
}

void InspectorForensicsAgent::handleScrollIntoViewForensics(Element* element, bool alignToTop){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleScrollIntoViewForensics");
	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleScrollIntoViewForensics : Element: ",std::to_string((long) element),", alignToTop: ", std::to_string(alignToTop));
}

void InspectorForensicsAgent::handleRequestFullscreenForensics(Element* element, bool hasPrefix){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRequestFullscreenForensics");
	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRequestFullscreenForensics : Element: ",std::to_string((long) element),", hasPrefix: ", std::to_string(hasPrefix));
}

void InspectorForensicsAgent::handleExitFullscreenForensics(Document* document){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleExitFullscreenForensics");
	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleExitFullscreenForensics : Document: ", std::to_string((long) document));

}

bool InspectorForensicsAgent::handleGetCSSGetPropertyPriorityForensics(String& data){

	return false;
}

bool InspectorForensicsAgent::handleGetEventTimeStampForensics(double& timeStamp){

	return false;
}
void InspectorForensicsAgent::handleSetEventTimeStampForensics(double timeStamp){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleSetEventTimeStampForensics");
	if(m_recording&& m_inJSCounter>0){
		m_dataStore->recordEventTimeStampDataStore(timeStamp);
	}
}

void InspectorForensicsAgent::handleWindowOpenForensics(const String& urlString, const AtomicString& frameName, const String& windowFeaturesString){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleWindowOpenForensics");
	if(m_recording&& m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleWindowOpenForensics : URL: ",urlString.latin1().data(),", frameName: ",String(frameName).latin1().data(),", windowFeaturesString: ", windowFeaturesString.latin1().data());
	}
}

void InspectorForensicsAgent::handleRecordElementFocusForensics(Element* element){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordElementFocusForensics");
	if(m_recording&& m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRecordElementFocusForensics: Focused Element: ", std::to_string((long) element));
	}
}

void InspectorForensicsAgent::handleRecordElementBlurForensics(Element* element){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordElementBlurForensics");
	if(m_recording&& m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRecordElementBlurForensics: Blured(unfocused) Element: ", std::to_string((long) element));
	}
}

void InspectorForensicsAgent::handleRecordWindowScrollToXYForensics(LocalFrame* frame, double x, double y){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordWindowScrollToXYForensics");
	if(m_recording&& m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRecordWindowScrollToXYForensics: Frame: ",std::to_string((long) frame),", X: ",std::to_string(x),", Y: ", std::to_string(y));
	}
}

void InspectorForensicsAgent::handleRecordSetLocationForensics(LocalFrame* frame, const String& url){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordSetLocationForensics");
	if(m_recording&& m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRecordSetLocationForensics: Frame: ",std::to_string((long) frame),", URL: ", url.latin1().data());
	}
}

void InspectorForensicsAgent::handleRecordSubmitFromJavaScript(Element* element){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordSubmitFromJavaScript");
	if(m_recording&& m_inJSCounter>0){
		HTMLFormElement* new_element = static_cast<HTMLFormElement*>(element);
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRecordSubmitFromJavaScript: Node: ",std::to_string((long) element),", Method: ",new_element->method().latin1().data(),", Action: ",new_element->action().latin1().data(),", Name: ", new_element->name().latin1().data());
	}
}

void InspectorForensicsAgent::handleRecordHistoryStateObjectAdded(LocalFrame* frame, const String& urlString, unsigned type){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordHistoryStateObjectAdded");
	if(m_recording&& m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRecordHistoryStateObjectAdded: frame: ",std::to_string((long) frame),",  Url: ",urlString.latin1().data(),", Type: ", std::to_string(type));
	}
}

void InspectorForensicsAgent::handleRecordHTMLMediaElementLoad(Element* element){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordHTMLMediaElementLoad");
	if(m_recording&& m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRecordHTMLMediaElementLoad: Element: ", std::to_string((long) element));
	}
}

void InspectorForensicsAgent::handleRecordHTMLMediaElementPlayForensics(Element* element){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordHTMLMediaElementPlayForensics");
	if(m_recording&& m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRecordHTMLMediaElementPlayForensics: Element: ", std::to_string((long) element));
	}
}

void InspectorForensicsAgent::handleRecordRegisterIdleTaskCallback(IdleRequestCallback* callback, int id, long long timeoutMillis){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordRegisterIdleTaskCallback");
	if(m_recording&& m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRecordRegisterIdleTaskCallback: Callback: ",std::to_string((long) callback),", id: ",std::to_string(id),", timeoutMillis: ", std::to_string(timeoutMillis));
	}	
}

void InspectorForensicsAgent::handleRecordIdleTaskCallbackFiredForensics(int id, double deadlineSeconds, unsigned callbackType){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordIdleTaskCallbackFiredForensics");
	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRecordIdleTaskCallbackFiredForensics: id: ",std::to_string(id),", deadlineSeconds: ",std::to_string(deadlineSeconds),", callbackType: ", std::to_string(callbackType));

}

void InspectorForensicsAgent::handleRecordRegisterMutationObserverForensics(Node* node, MutationObserver* observer, unsigned char options, const HashSet<AtomicString>& attributeFilter){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleRecordRegisterMutationObserverForensics");
	std::ostringstream output;
	if(m_recording&& m_inJSCounter>0){
		for(AtomicString it:attributeFilter){
			output << String(it).latin1().data();
			output << ",";
		}
		
		const std::string& result = output.str();
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleRecordRegisterMutationObserverForensics: Node: ",std::to_string((long) node),", Observer: ",std::to_string((long) observer),", options: ",std::to_string((unsigned) options),", attributeFilter: ", result.c_str());
	}	
}

void InspectorForensicsAgent::willDeliverMutationRecords(ExecutionContext*, MutationObserver* observer){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::willDeliverMutationRecords");
	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::willDeliverMutationRecords: Observer: ", std::to_string((long) observer));
}

void InspectorForensicsAgent::handleModaldialogConfirmResultRecording(const String& message, bool result){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleModaldialogConfirmResultRecording");
	if(m_recording&& m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleModaldialogConfirmResultRecording: Message: ",message.latin1().data(),", Result: ", std::to_string((int) result));
	}
}

void InspectorForensicsAgent::handleModaldialogPromptResultRecording(const String& message, const String& result){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleModaldialogPromptResultRecording");
	if(m_recording&& m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleModaldialogPromptResultRecording: Message: ",message.latin1().data(),", Result: ", result.latin1().data());
	}
}

void InspectorForensicsAgent::handleModaldialogAlertRecording(const String& message){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleModaldialogAlertRecording");
	if(m_recording&& m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleModaldialogAlertRecording: Message: ", message.latin1().data());
	}
}

void InspectorForensicsAgent::handleWindowFocusForensics(LocalFrame* frame){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleWindowFocusForensics");
	if(m_recording&& m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleWindowFocusForensics: frame: ", std::to_string((long) frame));
	}
}

void InspectorForensicsAgent::handleWindowBlurForensics(LocalFrame* frame){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleWindowBlurForensics");
	if(m_recording&& m_inJSCounter>0){
		m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleWindowBlurForensics: frame: ", std::to_string((long) frame));
	}
}

void InspectorForensicsAgent::handleHandleClickForensics(const KURL& url){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleHandleClickForensics");
	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleHandleClickForensics: URL: ", url.string().latin1().data());
}

void InspectorForensicsAgent::handleMaybeHandleHttpRefreshForensics(LocalFrame* frame, const String& refreshURL, double delay){
	TRACE_EVENT0("jsgraph", "JSCapsule::InspectorForensicsAgent::handleMaybeHandleHttpRefreshForensics");
	m_blinkPlatform->fileUtilities()->tab_log_combine("InspectorForensicsAgent::handleMaybeHandleHttpRefreshForensics: Frame: ", std::to_string((long) frame), ", URL: ", refreshURL.latin1().data(), ", Delay: ", std::to_string(delay));

}

void InspectorForensicsAgent::domContentLoadedEventFired(LocalFrame* frame){
	if (frame==m_mainFrame){
		TRACE_EVENT_END0("jsgraph", "JSCapsule::InspectorForensicsAgent::domContentLoadedEventFired");
	}
}

void InspectorForensicsAgent::loadEventFired(LocalFrame* frame){
	if (frame==m_mainFrame){
		TRACE_EVENT_END0("jsgraph", "JSCapsule::InspectorForensicsAgent::loadEventFired");
	}
}
void InspectorForensicsAgent::didCommitLoad(LocalFrame* frame, DocumentLoader*){
	if (frame==m_mainFrame){
		TRACE_EVENT_END0("jsgraph", "JSCapsule::InspectorForensicsAgent::didCommitLoad");
	}
}

void InspectorForensicsAgent::frameStoppedLoading(LocalFrame* frame){
	if (frame==m_mainFrame){
		TRACE_EVENT_END0("jsgraph", "JSCapsule::InspectorForensicsAgent::frameStoppedLoading");
	}
}

void InspectorForensicsAgent::frameScheduledNavigation(LocalFrame* frame, double delay){
	if (frame==m_mainFrame){
		TRACE_EVENT_END0("jsgraph", "JSCapsule::InspectorForensicsAgent::frameScheduledNavigation");
	}
}

void InspectorForensicsAgent::willCloseWindow(){
	m_blinkPlatform->fileUtilities()->tab_log_cleanup();
}

void InspectorForensicsAgent::handleDocumentDispatchUnloadEventsForensics(){
	m_blinkPlatform->fileUtilities()->tab_log_cleanup();
}

void InspectorForensicsAgent::willInsertDOMNode(Node* parent){

}

void InspectorForensicsAgent::takeDOMTextSnapshot(LocalFrame* frame, String& domSnapshot, double timestamp) {
	domSnapshot.append("\n<!--- WEBCAPSULE : DOM_SNAPTHOT : BEGIN : ID=");
	domSnapshot.append(String::numberToStringFixedWidth(timestamp,NUMBER_TO_STRING_DECIMAL_DIGITS));
	domSnapshot.append(" --->\n");
	frameContentAsPlainText(frame, domSnapshot);
	domSnapshot.append("\n<!--- WEBCAPSULE : DOM_SNAPTHOT : END : ID=");
	domSnapshot.append(String::numberToStringFixedWidth(timestamp,NUMBER_TO_STRING_DECIMAL_DIGITS));
	domSnapshot.append(" --->\n");
}

// code borrowed from web/WebFrameImpl.cpp
// we made it a member of InspectorForensicsAgent so that we can make changes, if needed...
// static
void InspectorForensicsAgent::frameContentAsPlainText(LocalFrame* frame, String& output)
{
    Document* document = frame->document();
    if (!document)
        return;

    if (!frame->view())
        return;

    // TextIterator iterates over the visual representation of the DOM. As such,
    // it requires you to do a layout before using it (otherwise it'll crash).
    document->updateLayout();

    output.append("\n<!--- WEBCAPSULE : FRAME URL = ");
    output.append(document->url().string());
    output.append(" --->\n");

    output.append(document->head()->outerHTML());
    output.append(document->body()->outerHTML());

    // Recursively walk the children.
    const FrameTree& frameTree = frame->tree();
    for (Frame* curChild = frameTree.firstChild(); curChild; curChild = curChild->tree().nextSibling()) {
        if (!curChild->isLocalFrame())
      		continue;
    	LocalFrame* curLocalChild = toLocalFrame(curChild);
        String visibleStr;
        LayoutView* contentLayoutObject = curLocalChild->contentLayoutObject();
        LayoutPart* ownerLayoutObject = curLocalChild->ownerLayoutObject();
        if (!contentLayoutObject || !contentLayoutObject->size().width() || !contentLayoutObject->size().height()
            || (contentLayoutObject->location().x() + contentLayoutObject->size().width() <= 0) || (contentLayoutObject->location().y() + contentLayoutObject->size().height() <= 0)
            || (ownerLayoutObject && ownerLayoutObject->style() && ownerLayoutObject->style()->visibility() != VISIBLE)) {
            visibleStr = "\n<!--- WEBCAPSULE : FRAME VISIBILITY = INVISIBLE --->\n";
            // continue; // Ignore the text of non-visible frames.
        }
        else {
            visibleStr = "\n<!--- WEBCAPSULE : FRAME VISIBILITY = VISIBLE --->\n";
        }

        output.append("\n<!--- WEBCAPSULE : FRAME_SNAPTHOT : BEGIN --->\n");
        output.append(visibleStr);
        frameContentAsPlainText(curLocalChild, output);
        output.append("\n<!--- WEBCAPSULE : FRAME_SNAPTHOT : END --->\n");
    }
}

void InspectorForensicsAgent::logFrameContent(){
    if(Forensics::isTakeDOMTextSnapshotAllowed()){
    	String domSnapshot;
    	takeDOMTextSnapshot(m_mainFrame, domSnapshot, Forensics::getCurrentTimeMs());
    	m_blinkPlatform->fileUtilities()->tab_log_combine(domSnapshot.latin1().data());
    }
}

String InspectorForensicsAgent::getParentChain(Node* node, int level){
	Node* tempNode;
	String returnString = String();
	tempNode = node;
	for (int i=0; i<level; i++){
		if(tempNode->parentNode()){
			tempNode = tempNode->parentNode();
			returnString = returnString + tempNode->nodeName();
			if(i<level-1 && tempNode->parentNode()){
				returnString = returnString + " -> ";
			}
		}
		else{
			break;
		}
	}
	return returnString;
}

bool InspectorForensicsAgent::isJSInsertedFrameNode(Node* node){
	return (node->ownerDocument() &&  node->ownerDocument()!= m_JSDocumentStack.peek());
	
}

bool InspectorForensicsAgent::isRecordEventInJS(){
	return (!m_RecordEventInJSStack.isEmpty()) && m_RecordEventInJSStack.peek();
}

bool InspectorForensicsAgent::isJSInsertedFrameContext(ExecutionContext* context){
	Document* document = context->isDocument()? static_cast<Document*>(context) : nullptr;
	return (document && document!= m_JSDocumentStack.peek());
	
}

DEFINE_TRACE(InspectorForensicsAgent)
{
    visitor->trace(m_pageAgent);
    InspectorBaseAgent::trace(visitor);
}

} // namespace blink
