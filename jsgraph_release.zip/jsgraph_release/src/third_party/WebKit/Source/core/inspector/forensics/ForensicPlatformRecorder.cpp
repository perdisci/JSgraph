/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/

#include "config.h"
#include "core/inspector/forensics/ForensicPlatformRecorder.h"
#include "public/platform/WebURLLoader.h"

namespace blink {

PassRefPtr<ForensicPlatformRecorder> ForensicPlatformRecorder::create(Platform* blinkPlatform, PassRefPtr<ForensicDataStore> dataStore) {
    return adoptRef(new ForensicPlatformRecorder(blinkPlatform, dataStore));
}

ForensicPlatformRecorder::ForensicPlatformRecorder(Platform* blinkPlatform, PassRefPtr<ForensicDataStore> dataStore)     
    : ForensicPlatformWrapper(blinkPlatform) 
    , m_dataStore(dataStore)
{
}

ForensicPlatformRecorder::~ForensicPlatformRecorder() 
{ 
}

WebURLLoader* ForensicPlatformRecorder::createURLLoader() {
    WTF_LOG(Forensics, "ForensicPlatformRecorder::createURLLoader");
    return blinkPlatform()->createURLLoader();
}

WebCookieJar* ForensicPlatformRecorder::cookieJar() {
	WTF_LOG(Forensics, "ForensicPlatformRecorder::cookieJar");
	return blinkPlatform()->cookieJar();
}

} // namespace blink
