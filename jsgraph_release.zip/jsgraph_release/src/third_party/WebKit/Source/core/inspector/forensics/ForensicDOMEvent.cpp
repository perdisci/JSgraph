/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/

#include "config.h"
#include "core/inspector/forensics/ForensicDOMEvent.h"
#include "platform/weborigin/KURL.h"
#include "core/dom/Document.h"
#include "core/dom/Node.h"

//Base class for DOM event

namespace blink {


ForensicDOMEvent::ForensicDOMEvent(const KURL& pageURL, double timeStampMs)
    : ForensicPageEvent(pageURL, timeStampMs)
{
}

} // namespace blink
