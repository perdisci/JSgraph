/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/

#ifndef ForensicPlatformWrapper_h
#define ForensicPlatformWrapper_h

#include "public/platform/Platform.h"
#include "platform/Logging.h"

namespace blink {

class WebAudioBus;
class WebBlobRegistry;
class WebBluetooth;
class WebClipboard;
class WebCompositorSupport;
class WebConvertableToTraceFormat;
class WebCookieJar;
class WebCrypto;
class WebDatabaseObserver;
class WebDiscardableMemory;
class WebPlatformEventListener;
class WebFallbackThemeEngine;
class WebFileSystem;
class WebFileUtilities;
class WebFlingAnimator;
class WebGeofencingProvider;
class WebGestureCurve;
class WebGraphicsContext3DProvider;
class WebIDBFactory;
class WebMIDIAccessor;
class WebMIDIAccessorClient;
class WebMediaRecorderHandler;
class WebMediaStreamCenter;
class WebMediaStreamCenterClient;
class WebMemoryDumpProvider;
class WebMessagePortChannel;
class WebMimeRegistry;
class WebNavigatorConnectProvider;
class WebNotificationManager;
class WebPermissionClient;
class WebPluginListBuilder;
class WebPrescientNetworking;
class WebProcessMemoryDump;
class WebPublicSuffixList;
class WebPushProvider;
class WebRTCPeerConnectionHandler;
class WebRTCPeerConnectionHandlerClient;
class WebSandboxSupport;
class WebScrollbarBehavior;
class WebSecurityOrigin;
class WebServicePortProvider;
class WebServicePortProviderClient;
class WebServiceWorkerCacheStorage;
class WebSocketHandle;
class WebSpeechSynthesizer;
class WebSpeechSynthesizerClient;
class WebStorageNamespace;
class WebSyncProvider;
struct WebFloatPoint;
class WebThemeEngine;
class WebThread;
class WebURL;
class WebURLLoader;
class WebUnitTestSupport;
struct WebLocalizedString;
struct WebSize;

class ForensicPlatformWrapper : public Platform {
public:
    // HTML5 Database ------------------------------------------------------

#ifdef WIN32
    typedef HANDLE FileHandle;
#else
    typedef int FileHandle;
#endif

    // BLINK_PLATFORM_EXPORT static void initialize(Platform*);
    // BLINK_PLATFORM_EXPORT static void shutdown();
    // BLINK_PLATFORM_EXPORT static Platform* current();

    // May return null.
    virtual WebCookieJar* cookieJar() { return m_blinkPlatform->cookieJar(); }

    // Must return non-null.
    virtual WebClipboard* clipboard() { return m_blinkPlatform->clipboard(); }

    // Must return non-null.
    virtual WebFileUtilities* fileUtilities() { return m_blinkPlatform->fileUtilities(); }

    // Must return non-null.
    virtual WebMimeRegistry* mimeRegistry() { return m_blinkPlatform->mimeRegistry(); }

    // May return null if sandbox support is not necessary
    virtual WebSandboxSupport* sandboxSupport() { return m_blinkPlatform->sandboxSupport(); }

    // May return null on some platforms.
    virtual WebThemeEngine* themeEngine() { return m_blinkPlatform->themeEngine(); }

    virtual WebFallbackThemeEngine* fallbackThemeEngine() { return m_blinkPlatform->fallbackThemeEngine(); }

    // May return null.
    virtual WebSpeechSynthesizer* createSpeechSynthesizer(WebSpeechSynthesizerClient* s) { return m_blinkPlatform->createSpeechSynthesizer(s); }


    // Audio --------------------------------------------------------------

    virtual double audioHardwareSampleRate() { return m_blinkPlatform->audioHardwareSampleRate(); }
    virtual size_t audioHardwareBufferSize() { return m_blinkPlatform->audioHardwareBufferSize(); }
    virtual unsigned audioHardwareOutputChannels() { return m_blinkPlatform->audioHardwareOutputChannels(); }

    // Creates a device for audio I/O.
    // Pass in (numberOfInputChannels > 0) if live/local audio input is desired.
    virtual WebAudioDevice* createAudioDevice(size_t bufferSize, unsigned numberOfInputChannels, unsigned numberOfChannels, double sampleRate, WebAudioDevice::RenderCallback* r, const WebString& deviceId) { return m_blinkPlatform->createAudioDevice(bufferSize, numberOfInputChannels, numberOfChannels, sampleRate, r, deviceId); }


    // MIDI ----------------------------------------------------------------

    // Creates a platform dependent WebMIDIAccessor. MIDIAccessor under platform
    // creates and owns it.
    virtual WebMIDIAccessor* createMIDIAccessor(WebMIDIAccessorClient* c) { return m_blinkPlatform->createMIDIAccessor(c); }


    // Blob ----------------------------------------------------------------

    // Must return non-null.
    virtual WebBlobRegistry* blobRegistry() { return m_blinkPlatform->blobRegistry(); }

    // Database ------------------------------------------------------------

    // Opens a database file; dirHandle should be 0 if the caller does not need
    // a handle to the directory containing this file
    virtual FileHandle databaseOpenFile(const WebString& vfsFileName, int desiredFlags) { return m_blinkPlatform->databaseOpenFile(vfsFileName, desiredFlags); }

    // Deletes a database file and returns the error code
    virtual int databaseDeleteFile(const WebString& vfsFileName, bool syncDir) { return m_blinkPlatform->databaseDeleteFile(vfsFileName, syncDir); }

    // Returns the attributes of the given database file
    virtual long databaseGetFileAttributes(const WebString& vfsFileName) { return m_blinkPlatform->databaseGetFileAttributes(vfsFileName); }

    // Returns the size of the given database file
    virtual long long databaseGetFileSize(const WebString& vfsFileName) { return m_blinkPlatform->databaseGetFileSize(vfsFileName); }

    // Returns the space available for the given origin
    virtual long long databaseGetSpaceAvailableForOrigin(const WebString& originIdentifier) { return m_blinkPlatform->databaseGetSpaceAvailableForOrigin(originIdentifier); }

    // Set the size of the given database file
    virtual bool databaseSetFileSize(const WebString& vfsFileName, long long size) { return m_blinkPlatform->databaseSetFileSize(vfsFileName, size); }


    // DOM Storage --------------------------------------------------

    // Return a LocalStorage namespace
    virtual WebStorageNamespace* createLocalStorageNamespace() { return m_blinkPlatform->createLocalStorageNamespace(); }


    // FileSystem ----------------------------------------------------------

    // Must return non-null.
    virtual WebFileSystem* fileSystem() { return m_blinkPlatform->fileSystem(); }


    // IDN conversion ------------------------------------------------------

    virtual WebString convertIDNToUnicode(const WebString& host, const WebString& languages) { return m_blinkPlatform->convertIDNToUnicode(host, languages); }


    // IndexedDB ----------------------------------------------------------

    // Must return non-null.
    virtual WebIDBFactory* idbFactory() { return m_blinkPlatform->idbFactory(); }


    // Cache Storage ----------------------------------------------------------

    // The caller is responsible for deleting the returned object.
    virtual WebServiceWorkerCacheStorage* cacheStorage(const WebString& originIdentifier) { return m_blinkPlatform->cacheStorage(originIdentifier); }

    // Gamepad -------------------------------------------------------------

    virtual void sampleGamepads(WebGamepads& into) { m_blinkPlatform->sampleGamepads(into); }

    // History -------------------------------------------------------------

    // Returns the hash for the given canonicalized URL for use in visited
    // link coloring.
    virtual unsigned long long visitedLinkHash(
        const char* canonicalURL, size_t length) { return m_blinkPlatform->visitedLinkHash(canonicalURL, length); }

    // Returns whether the given link hash is in the user's history. The
    // hash must have been generated by calling VisitedLinkHash().
    virtual bool isLinkVisited(unsigned long long linkHash) { return m_blinkPlatform->isLinkVisited(linkHash); }


    // Keygen --------------------------------------------------------------

    // Handle the <keygen> tag for generating client certificates
    // Returns a base64 encoded signed copy of a public key from a newly
    // generated key pair and the supplied challenge string. keySizeindex
    // specifies the strength of the key.
    virtual WebString signedPublicKeyAndChallengeString(unsigned keySizeIndex,
                                                        const WebString& challenge,
                                                        const WebURL& url) { return m_blinkPlatform->signedPublicKeyAndChallengeString(keySizeIndex, challenge, url); }


    // Memory --------------------------------------------------------------

    // Returns the current space allocated for the pagefile, in MB.
    // That is committed size for Windows and virtual memory size for POSIX
    virtual size_t memoryUsageMB() { return m_blinkPlatform->memoryUsageMB(); }

    // Same as above, but always returns actual value, without any caches.
    virtual size_t actualMemoryUsageMB() { return m_blinkPlatform->actualMemoryUsageMB(); }

    // Return the physical memory of the current machine, in MB.
    virtual size_t physicalMemoryMB() { return m_blinkPlatform->physicalMemoryMB(); }

    // Return the available virtual memory of the current machine, in MB. Or
    // zero, if there is no limit.
    virtual size_t virtualMemoryLimitMB() { return m_blinkPlatform->virtualMemoryLimitMB(); }

    // True when Blink runs on low end devices.
    virtual bool isLowEndDeviceMode() { return m_blinkPlatform->isLowEndDeviceMode(); }

    // Return the number of of processors of the current machine.
    virtual size_t numberOfProcessors() { return m_blinkPlatform->numberOfProcessors(); }

    // Returns private and shared usage, in bytes. Private bytes is the amount of
    // memory currently allocated to this process that cannot be shared. Returns
    // false on platform specific error conditions.
    virtual bool processMemorySizesInBytes(size_t* privateBytes, size_t* sharedBytes) { return m_blinkPlatform->processMemorySizesInBytes(privateBytes, sharedBytes); }

    // Reports number of bytes used by memory allocator for internal needs.
    // Returns true if the size has been reported, or false otherwise.
    virtual bool memoryAllocatorWasteInBytes(size_t* b) { return m_blinkPlatform->memoryAllocatorWasteInBytes(b); }

    // Allocates discardable memory. May return nullptr, even if the platform supports
    // discardable memory. If nonzero, however, then the WebDiscardableMmeory is
    // returned in an locked state. You may use its underlying data() member
    // directly, taking care to unlock it when you are ready to let it become
    // discardable.
    virtual WebDiscardableMemory* allocateAndLockDiscardableMemory(size_t bytes) { return m_blinkPlatform->allocateAndLockDiscardableMemory(bytes); }

    // static const size_t noDecodedImageByteLimit = static_cast<size_t>(-1);

    // Returns the maximum amount of memory a decoded image should be allowed.
    // See comments on ImageDecoder::m_maxDecodedBytes.
    virtual size_t maxDecodedImageBytes() { return m_blinkPlatform->maxDecodedImageBytes(); }

    // Process -------------------------------------------------------------

    // Returns a unique identifier for a process. This may not necessarily be
    // the process's process ID.
    virtual uint32_t getUniqueIdForProcess() { return m_blinkPlatform->getUniqueIdForProcess(); }


    // Message Ports -------------------------------------------------------

    // Creates a Message Port Channel pair. This can be called on any thread.
    // The returned objects should only be used on the thread they were created on.
    virtual void createMessageChannel(WebMessagePortChannel** channel1, WebMessagePortChannel** channel2) { m_blinkPlatform->createMessageChannel(channel1, channel2); }


    // Network -------------------------------------------------------------

    // Returns a new WebURLLoader instance.
    virtual WebURLLoader* createURLLoader() { return m_blinkPlatform->createURLLoader(); }

    // May return null.
    virtual WebPrescientNetworking* prescientNetworking() { return m_blinkPlatform->prescientNetworking(); }

    // Returns a new WebSocketHandle instance.
    virtual WebSocketHandle* createWebSocketHandle() { return m_blinkPlatform->createWebSocketHandle(); }

    // Returns the User-Agent string.
    virtual WebString userAgent() { return m_blinkPlatform->userAgent(); }

    // A suggestion to cache this metadata in association with this URL.
    virtual void cacheMetadata(const WebURL& u, int64 responseTime, const char* data, size_t dataSize) { m_blinkPlatform->cacheMetadata(u, responseTime, data, dataSize); }

    // Returns the decoded data url if url had a supported mimetype and parsing was successful.
    virtual WebData parseDataURL(const WebURL& u, WebString& mimetype, WebString& charset) { return m_blinkPlatform->parseDataURL(u, mimetype, charset); }

    virtual WebURLError cancelledError(const WebURL& u) const { return m_blinkPlatform->cancelledError(u); }

    virtual bool isReservedIPAddress(const WebString& host) const { return m_blinkPlatform->isReservedIPAddress(host); }

    virtual bool portAllowed(const WebURL& u) const { return m_blinkPlatform->portAllowed(u); }

    // Plugins -------------------------------------------------------------

    // If refresh is true, then cached information should not be used to
    // satisfy this call.
    virtual void getPluginList(bool refresh, WebPluginListBuilder* b) { m_blinkPlatform->getPluginList(refresh, b); }


    // Public Suffix List --------------------------------------------------

    // May return null on some platforms.
    virtual WebPublicSuffixList* publicSuffixList() { return m_blinkPlatform->publicSuffixList(); }


    // Resources -----------------------------------------------------------

    // Returns a localized string resource (with substitution parameters).
    virtual WebString queryLocalizedString(WebLocalizedString::Name n) { return m_blinkPlatform->queryLocalizedString(n); }
    virtual WebString queryLocalizedString(WebLocalizedString::Name n, const WebString& parameter) { return m_blinkPlatform->queryLocalizedString(n, parameter); }
    virtual WebString queryLocalizedString(WebLocalizedString::Name n, const WebString& parameter1, const WebString& parameter2) { return m_blinkPlatform->queryLocalizedString(n, parameter1, parameter2); }


    // Threads -------------------------------------------------------

    // Creates an embedder-defined thread.
    virtual WebThread* createThread(const char* name) { return m_blinkPlatform->createThread(name); }

    // Returns an interface to the current thread. This is owned by the
    // embedder.
    virtual WebThread* currentThread() { return m_blinkPlatform->currentThread(); }

    // Yield the current thread so another thread can be scheduled.
    virtual void yieldCurrentThread() { m_blinkPlatform->yieldCurrentThread(); }

    // WaitableEvent -------------------------------------------------------

    // Creates an embedder-defined waitable event object.
    WebWaitableEvent* createWaitableEvent() { return m_blinkPlatform->createWaitableEvent(WebWaitableEvent::ResetPolicy::Auto, WebWaitableEvent::InitialState::NonSignaled); }
    virtual WebWaitableEvent* createWaitableEvent(WebWaitableEvent::ResetPolicy p, WebWaitableEvent::InitialState s) { return m_blinkPlatform->createWaitableEvent(p,s); }

    // Waits on multiple events and returns the event object that has been
    // signaled. This may return nullptr if it fails to wait events.
    // Any event objects given to this method must not deleted while this
    // wait is happening.
    virtual WebWaitableEvent* waitMultipleEvents(const WebVector<WebWaitableEvent*>& events) { return m_blinkPlatform->waitMultipleEvents(events); }


    // Profiling -----------------------------------------------------------

    virtual void decrementStatsCounter(const char* name) { return m_blinkPlatform->decrementStatsCounter(name); }
    virtual void incrementStatsCounter(const char* name) { return m_blinkPlatform->incrementStatsCounter(name); }


    // Resources -----------------------------------------------------------

    // Returns a blob of data corresponding to the named resource.
    virtual WebData loadResource(const char* name) { return m_blinkPlatform->loadResource(name); }

    // Decodes the in-memory audio file data and returns the linear PCM audio data in the destinationBus.
    // A sample-rate conversion to sampleRate will occur if the file data is at a different sample-rate.
    // Returns true on success.
    virtual bool loadAudioResource(WebAudioBus* destinationBus, const char* audioFileData, size_t dataSize) { return m_blinkPlatform->loadAudioResource(destinationBus, audioFileData, dataSize); }

    // Screen -------------------------------------------------------------

    // Supplies the system monitor color profile.
    virtual void screenColorProfile(WebVector<char>* profile) { m_blinkPlatform->screenColorProfile(profile); }


    // Scrollbar ----------------------------------------------------------

    // Must return non-null.
    virtual WebScrollbarBehavior* scrollbarBehavior() { return m_blinkPlatform->scrollbarBehavior(); }


    // Sudden Termination --------------------------------------------------

    // Disable/Enable sudden termination on a process level. When possible, it
    // is preferable to disable sudden termination on a per-frame level via
    // WebFrameClient::suddenTerminationDisablerChanged.
    virtual void suddenTerminationChanged(bool enabled) { m_blinkPlatform->suddenTerminationChanged(enabled); }


    // System --------------------------------------------------------------

    // Returns a value such as "en-US".
    virtual WebString defaultLocale() { return m_blinkPlatform->defaultLocale(); }

    // Wall clock time in seconds since the epoch.
    virtual double currentTime() { return m_blinkPlatform->currentTime(); }

    // Monotonically increasing time in seconds from an arbitrary fixed point in the past.
    // This function is expected to return at least millisecond-precision values. For this reason,
    // it is recommended that the fixed point be no further in the past than the epoch.
    virtual double monotonicallyIncreasingTime() { return m_blinkPlatform->monotonicallyIncreasingTime(); }

    // System trace time in seconds. For example, on Chrome OS, this timestamp should be
    // synchronized with ftrace timestamps.
    virtual double systemTraceTime() { return m_blinkPlatform->systemTraceTime(); }

    // WebKit clients must implement this funcion if they use cryptographic randomness.
    virtual void cryptographicallyRandomValues(unsigned char* buffer, size_t length) { m_blinkPlatform->cryptographicallyRandomValues(buffer, length); } 

    // Returns an interface to the main thread. Can be null if blink was initialized on a thread without a message loop.
    BLINK_PLATFORM_EXPORT WebThread* mainThread() const { return m_blinkPlatform->mainThread(); }

    // Vibration -----------------------------------------------------------

    // Starts a vibration for the given duration in milliseconds. If there is currently an active
    // vibration it will be cancelled before the new one is started.
    virtual void vibrate(unsigned time) { m_blinkPlatform->vibrate(time); }

    // Cancels the current vibration, if there is one.
    virtual void cancelVibration() { m_blinkPlatform->cancelVibration(); }


    // Testing -------------------------------------------------------------

    // Get a pointer to testing support interfaces. Will not be available in production builds.
    virtual WebUnitTestSupport* unitTestSupport() { return m_blinkPlatform->unitTestSupport(); }


    // Tracing -------------------------------------------------------------

    // Get a pointer to the enabled state of the given trace category. The
    // embedder can dynamically change the enabled state as trace event
    // recording is started and stopped by the application. Only long-lived
    // literal strings should be given as the category name. The implementation
    // expects the returned pointer to be held permanently in a local static. If
    // the unsigned char is non-zero, tracing is enabled. If tracing is enabled,
    // addTraceEvent is expected to be called by the trace event macros.
    virtual const unsigned char* getTraceCategoryEnabledFlag(const char* categoryName) { return m_blinkPlatform->getTraceCategoryEnabledFlag(categoryName); }

    typedef intptr_t TraceEventAPIAtomicWord;

    // Get a pointer to a global state of the given thread. An embedder is
    // expected to update the global state as the state of the embedder changes.
    // A sampling thread in the Chromium side reads the global state periodically
    // and reflects the sampling profiled results into about:tracing.
    virtual TraceEventAPIAtomicWord* getTraceSamplingState(const unsigned bucketName) { return m_blinkPlatform->getTraceSamplingState(bucketName); }

    typedef uint64_t TraceEventHandle;

    // Add a trace event to the platform tracing system. Depending on the actual
    // enabled state, this event may be recorded or dropped.
    // - phase specifies the type of event:
    //   - BEGIN ('B'): Marks the beginning of a scoped event.
    //   - END ('E'): Marks the end of a scoped event.
    //   - COMPLETE ('X'): Marks the beginning of a scoped event, but doesn't
    //     need a matching END event. Instead, at the end of the scope,
    //     updateTraceEventDuration() must be called with the TraceEventHandle
    //     returned from addTraceEvent().
    //   - INSTANT ('I'): Standalone, instantaneous event.
    //   - START ('S'): Marks the beginning of an asynchronous event (the end
    //     event can occur in a different scope or thread). The id parameter is
    //     used to match START/FINISH pairs.
    //   - FINISH ('F'): Marks the end of an asynchronous event.
    //   - COUNTER ('C'): Used to trace integer quantities that change over
    //     time. The argument values are expected to be of type int.
    //   - METADATA ('M'): Reserved for internal use.
    // - categoryEnabled is the pointer returned by getTraceCategoryEnabledFlag.
    // - name is the name of the event. Also used to match BEGIN/END and
    //   START/FINISH pairs.
    // - id optionally allows events of the same name to be distinguished from
    //   each other. For example, to trace the consutruction and destruction of
    //   objects, specify the pointer as the id parameter.
    // - numArgs specifies the number of elements in argNames, argTypes, and
    //   argValues.
    // - argNames is the array of argument names. Use long-lived literal strings
    //   or specify the COPY flag.
    // - argTypes is the array of argument types:
    //   - BOOL (1): bool
    //   - UINT (2): unsigned long long
    //   - INT (3): long long
    //   - DOUBLE (4): double
    //   - POINTER (5): void*
    //   - STRING (6): char* (long-lived null-terminated char* string)
    //   - COPY_STRING (7): char* (temporary null-terminated char* string)
    //   - CONVERTABLE (8): WebConvertableToTraceFormat
    // - argValues is the array of argument values. Each value is the unsigned
    //   long long member of a union of all supported types.
    // - convertableValues is the array of WebConvertableToTraceFormat classes
    //   that may be converted to trace format by calling asTraceFormat method.
    //   ConvertableToTraceFormat interface.
    //   convertableValues can be moved to another object by
    //   WebConvertableToTraceFormat::moveFrom() in addTraceEvent(), and thus
    //   should not be dereferenced (e.g. asTraceFormat() should not be called)
    //   after return from addTraceEvent().
    // - thresholdBeginId optionally specifies the value returned by a previous
    //   call to addTraceEvent with a BEGIN phase.
    // - threshold is used on an END phase event in conjunction with the
    //   thresholdBeginId of a prior BEGIN event. The threshold is the minimum
    //   number of microseconds that must have passed since the BEGIN event. If
    //   less than threshold microseconds has passed, the BEGIN/END pair is
    //   dropped.
    // - flags can be 0 or one or more of the following, ORed together:
    //   - COPY (0x1): treat all strings (name, argNames and argValues of type
    //     string) as temporary so that they will be copied by addTraceEvent.
    //   - HAS_ID (0x2): use the id argument to uniquely identify the event for
    //     matching with other events of the same name.
    //   - MANGLE_ID (0x4): specify this flag if the id parameter is the value
    //     of a pointer.
    virtual TraceEventHandle addTraceEvent(
        char phase,
        const unsigned char* categoryEnabledFlag,
        const char* name,
        unsigned long long id,
        unsigned long long bindId,
        double timestamp,
        int numArgs,
        const char** argNames,
        const unsigned char* argTypes,
        const unsigned long long* argValues,
        WebConvertableToTraceFormat* convertableValues,
        unsigned flags)
    {
        return m_blinkPlatform->addTraceEvent(phase, categoryEnabledFlag, name, id, bindId, timestamp, numArgs, argNames, argTypes, argValues, convertableValues, flags);
    }

    // Set the duration field of a COMPLETE trace event.
    virtual void updateTraceEventDuration(const unsigned char* categoryEnabledFlag, const char* name, TraceEventHandle t) { m_blinkPlatform->updateTraceEventDuration(categoryEnabledFlag, name, t); }

    // Callbacks for reporting histogram data.
    // CustomCounts histogram has exponential bucket sizes, so that min=1, max=1000000, bucketCount=50 would do.
    virtual void histogramCustomCounts(const char* name, int sample, int min, int max, int bucketCount) { m_blinkPlatform->histogramCustomCounts(name, sample, min, max, bucketCount); }
    // Enumeration histogram buckets are linear, boundaryValue should be larger than any possible sample value.
    virtual void histogramEnumeration(const char* name, int sample, int boundaryValue) { m_blinkPlatform->histogramEnumeration(name, sample, boundaryValue); }
    // Unlike enumeration histograms, sparse histograms only allocate memory for non-empty buckets.
    virtual void histogramSparse(const char* name, int sample) { m_blinkPlatform->histogramSparse(name, sample); }

    // Record to a RAPPOR privacy-preserving metric, see: https://www.chromium.org/developers/design-documents/rappor.
    // recordRappor records a sample string, while recordRapporURL records the domain and registry of a url.
    virtual void recordRappor(const char* metric, const WebString& sample) { m_blinkPlatform->recordRappor(metric, sample); }
    virtual void recordRapporURL(const char* metric, const blink::WebURL& url) { m_blinkPlatform->recordRapporURL(metric, url); }

    // Registers a memory dump provider. The WebMemoryDumpProvider::onMemoryDump
    // method will be called on the same thread that called the
    // registerMemoryDumpProvider() method.
    // See crbug.com/458295 for design docs.
    virtual void registerMemoryDumpProvider(blink::WebMemoryDumpProvider* p) { m_blinkPlatform->registerMemoryDumpProvider(p); }

    // Must be called on the thread that called registerMemoryDumpProvider().
    virtual void unregisterMemoryDumpProvider(blink::WebMemoryDumpProvider* p) { m_blinkPlatform->unregisterMemoryDumpProvider(p); }

    // Returns a newly allocated WebProcessMemoryDump instance.
    virtual blink::WebProcessMemoryDump* createProcessMemoryDump() { return m_blinkPlatform->createProcessMemoryDump(); }

    typedef uint64_t WebMemoryAllocatorDumpGuid;

    // Returns guid corresponding to the given string (the hash value) for
    // creating a WebMemoryAllocatorDump.
    virtual WebMemoryAllocatorDumpGuid createWebMemoryAllocatorDumpGuid(const WebString& guidStr) { return m_blinkPlatform->createWebMemoryAllocatorDumpGuid(guidStr); }

    // GPU ----------------------------------------------------------------
    //
    // May return null if GPU is not supported.
    // Returns newly allocated and initialized offscreen WebGraphicsContext3D instance.
    // Passing an existing context to shareContext will create the new context in the same share group as the passed context.
    virtual WebGraphicsContext3D* createOffscreenGraphicsContext3D(const WebGraphicsContext3D::Attributes& a, WebGraphicsContext3D* shareContext) { return m_blinkPlatform->createOffscreenGraphicsContext3D(a, shareContext); }
    virtual WebGraphicsContext3D* createOffscreenGraphicsContext3D(const WebGraphicsContext3D::Attributes& a, WebGraphicsContext3D* shareContext, WebGLInfo* glInfo) { return m_blinkPlatform->createOffscreenGraphicsContext3D(a, shareContext, glInfo); }
    virtual WebGraphicsContext3D* createOffscreenGraphicsContext3D(const WebGraphicsContext3D::Attributes& a) { return m_blinkPlatform->createOffscreenGraphicsContext3D(a); }

    // Returns a newly allocated and initialized offscreen context provider. The provider may return a null
    // graphics context if GPU is not supported.
    virtual WebGraphicsContext3DProvider* createSharedOffscreenGraphicsContext3DProvider() { return m_blinkPlatform->createSharedOffscreenGraphicsContext3DProvider(); }

    // Returns true if the platform is capable of producing an offscreen context suitable for accelerating 2d canvas.
    // This will return false if the platform cannot promise that contexts will be preserved across operations like
    // locking the screen or if the platform cannot provide a context with suitable performance characteristics.
    //
    // This value must be checked again after a context loss event as the platform's capabilities may have changed.
    virtual bool canAccelerate2dCanvas() { return m_blinkPlatform->canAccelerate2dCanvas(); }

    virtual bool isThreadedCompositingEnabled() { return m_blinkPlatform->isThreadedCompositingEnabled(); }
    virtual bool isThreadedAnimationEnabled() { return m_blinkPlatform->isThreadedAnimationEnabled(); }

    virtual WebCompositorSupport* compositorSupport() { return m_blinkPlatform->compositorSupport(); }

    virtual WebFlingAnimator* createFlingAnimator() { return m_blinkPlatform->createFlingAnimator(); }

    // Creates a new fling animation curve instance for device |deviceSource|
    // with |velocity| and already scrolled |cumulativeScroll| pixels.
    virtual WebGestureCurve* createFlingAnimationCurve(WebGestureDevice deviceSource, const WebFloatPoint& velocity, const WebSize& cumulativeScroll) { return m_blinkPlatform->createFlingAnimationCurve(deviceSource, velocity, cumulativeScroll); }

    // WebRTC ----------------------------------------------------------

    // Creates an WebRTCPeerConnectionHandler for RTCPeerConnection.
    // May return null if WebRTC functionality is not avaliable or out of resources.
    virtual WebRTCPeerConnectionHandler* createRTCPeerConnectionHandler(WebRTCPeerConnectionHandlerClient* w) { return m_blinkPlatform->createRTCPeerConnectionHandler(w); }

    // Creates an WebMediaRecorderHandler to record MediaStreams.
    // May return null if the functionality is not available or out of resources.
    virtual WebMediaRecorderHandler* createMediaRecorderHandler() { return m_blinkPlatform->createMediaRecorderHandler(); }

    // May return null if WebRTC functionality is not avaliable or out of resources.
    virtual WebMediaStreamCenter* createMediaStreamCenter(WebMediaStreamCenterClient* w) { return m_blinkPlatform->createMediaStreamCenter(w); }

    // WebWorker ----------------------------------------------------------

    virtual void didStartWorkerRunLoop() { m_blinkPlatform->didStartWorkerRunLoop(); }
    virtual void didStopWorkerRunLoop() { m_blinkPlatform->didStopWorkerRunLoop(); }

    // WebCrypto ----------------------------------------------------------

    virtual WebCrypto* crypto() { return m_blinkPlatform->crypto(); }


    // Platform events -----------------------------------------------------
    // Device Orientation, Device Motion, Device Light, Battery, Gamepad.

    // Request the platform to start listening to the events of the specified
    // type and notify the given listener (if not null) when there is an update.
    virtual void startListening(WebPlatformEventType type, WebPlatformEventListener* listener) { m_blinkPlatform->startListening(type, listener); }

    // Request the platform to stop listening to the specified event and no
    // longer notify the listener, if any.
    virtual void stopListening(WebPlatformEventType type) { m_blinkPlatform->stopListening(type); }

    // This method converts from the supplied DOM code enum to the
    // embedder's DOM code value for the key pressed. |domCode| values are
    // based on the value defined in ui/events/keycodes/dom4/keycode_converter_data.h.
    // Returns null string, if DOM code value is not found.
    virtual WebString domCodeStringFromEnum(int domCode) { return m_blinkPlatform->domCodeStringFromEnum(domCode); }

    // This method converts from the suppled DOM code value to the
    // embedder's DOM code enum for the key pressed. |codeString| is defined in
    // ui/events/keycodes/dom4/keycode_converter_data.h.
    // Returns 0, if DOM code enum is not found.
    virtual int domEnumFromCodeString(const WebString& codeString) { return m_blinkPlatform->domEnumFromCodeString(codeString); }

    // This method converts from the supplied DOM |key| enum to the
    // corresponding DOM |key| string value for the key pressed. |domKey| values are
    // based on the value defined in ui/events/keycodes/dom3/dom_key_data.h.
    // Returns empty string, if DOM key value is not found.
    virtual WebString domKeyStringFromEnum(int domKey) { return m_blinkPlatform->domKeyStringFromEnum(domKey); }

    // This method converts from the suppled DOM |key| value to the
    // embedder's DOM |key| enum for the key pressed. |keyString| is defined in
    // ui/events/keycodes/dom3/dom_key_data.h.
    // Returns 0 if DOM key enum is not found.
    virtual int domKeyEnumFromString(const WebString& keyString) { return m_blinkPlatform->domKeyEnumFromString(keyString); }

    // Quota -----------------------------------------------------------

    // Queries the storage partition's storage usage and quota information.
    // WebStorageQuotaCallbacks::didQueryStorageUsageAndQuota will be called
    // with the current usage and quota information for the partition. When
    // an error occurs WebStorageQuotaCallbacks::didFail is called with an
    // error code.
    virtual void queryStorageUsageAndQuota(
        const WebURL& storagePartition,
        WebStorageQuotaType t,
        WebStorageQuotaCallbacks c) { m_blinkPlatform->queryStorageUsageAndQuota(storagePartition, t, c); }


    // WebDatabase --------------------------------------------------------

    virtual WebDatabaseObserver* databaseObserver() { return m_blinkPlatform->databaseObserver(); }


    // Web Notifications --------------------------------------------------

    virtual WebNotificationManager* notificationManager() { return m_blinkPlatform->notificationManager(); }


    // Geofencing ---------------------------------------------------------

    virtual WebGeofencingProvider* geofencingProvider() { return m_blinkPlatform->geofencingProvider(); }


    // Bluetooth ----------------------------------------------------------

    // Returns pointer to client owned WebBluetooth implementation.
    virtual WebBluetooth* bluetooth() { return m_blinkPlatform->bluetooth(); }


    // Push API------------------------------------------------------------

    virtual WebPushProvider* pushProvider() { return m_blinkPlatform->pushProvider(); }


    // navigator.connect --------------------------------------------------

    virtual WebNavigatorConnectProvider* navigatorConnectProvider() { return m_blinkPlatform->navigatorConnectProvider(); }

    // Returns pointer to a new blink owned WebServicePortProvider instance,
    // associated with a particular ServicePortCollection (identified by the
    // WebServicePortProviderClient passed in).
    virtual WebServicePortProvider* createServicePortProvider(WebServicePortProviderClient* c) { return m_blinkPlatform->createServicePortProvider(c); }

    // Permissions --------------------------------------------------------

    virtual WebPermissionClient* permissionClient() { return m_blinkPlatform->permissionClient(); }


    // Background Sync API------------------------------------------------------------

    virtual WebSyncProvider* backgroundSyncProvider() { return m_blinkPlatform->backgroundSyncProvider(); }


    // WebCapsule ---------------------------------------------------------

    Platform* blinkPlatform() { return m_blinkPlatform; }    

protected:

    BLINK_PLATFORM_EXPORT ForensicPlatformWrapper(Platform* blinkPlatform) : m_blinkPlatform(blinkPlatform) { }
    virtual ~ForensicPlatformWrapper() { }

    Platform* m_blinkPlatform;
};

} // namespace blink

#endif // ForensicPlatformWrapper_h
