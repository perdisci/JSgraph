#include "config.h"
#include "core/inspector/forensics/Forensics.h"
#include "core/frame/LocalFrame.h"
#include "public/web/WebInputEvent.h"
#include "platform/weborigin/KURL.h"
#include "core/dom/Document.h"
#include "platform/Logging.h"
#include "public/platform/Platform.h"
#include "public/platform/WebScheduler.h"
#include "core/dom/Element.h"
#include "core/frame/FrameView.h"
#include "core/layout/LayoutView.h"
#include "core/layout/HitTestResult.h"
#include "core/html/HTMLFrameOwnerElement.h"
#include "public/web/WebInputEvent.h"
#include "core/dom/Node.h"
#include "core/page/Page.h"
#include "core/page/FocusController.h"
#include "core/dom/ExecutionContext.h"
#include "core/editing/serializers/MarkupAccumulator.h"
#include "core/dom/Node.h"

namespace blink {

bool Forensics::s_isJavaScriptAllowed = true;
bool Forensics::s_isAsynchronousParsingAllowed = false;
bool Forensics::s_isBlockNetworkRequest = false; //NOTE(Bo): this is a temp solution, will be removed later
bool Forensics::s_isInstallDomTimer = true;
bool Forensics::s_isRunWebWorker = true;
bool Forensics::s_isSendXMLRequest = true;
bool Forensics::s_isTakeDOMTextSnapshotAllowed = false;
bool Forensics::s_isSetWeakCallback = true;
bool Forensics::s_isOutputBackgroundImage=true;

bool Forensics::isJavaScriptAllowed() {
    return s_isJavaScriptAllowed;
}

void Forensics::setIsJavaScriptAllowed(bool val) {
    s_isJavaScriptAllowed = val;
    WTF_LOG(Forensics, "Forensics : val = %d", val);
    WTF_LOG(Forensics, "Forensics : s_isJavaScriptAllowed = %d", s_isJavaScriptAllowed);
    WTF_LOG(Forensics, "Forensics : isJavaScriptAllowed = %d", isJavaScriptAllowed());
}

bool Forensics::isTakeDOMTextSnapshotAllowed() {
    return s_isTakeDOMTextSnapshotAllowed;
}

void Forensics::setIsTakeDOMTextSnapshotAllowed(bool val) {
    s_isTakeDOMTextSnapshotAllowed = val;
    WTF_LOG(Forensics, "Forensics : val = %d", val);
    WTF_LOG(Forensics, "Forensics : s_isTakeDOMTextSnapshotAllowed = %d", s_isTakeDOMTextSnapshotAllowed);
    WTF_LOG(Forensics, "Forensics : isTakeDOMTextSnapshotAllowed = %d", isTakeDOMTextSnapshotAllowed());
}

bool Forensics::isAsynchronousParsingAllowed() {
    return s_isAsynchronousParsingAllowed;
}

void Forensics::setIsAsynchronousParsingAllowed(bool val) {
    s_isAsynchronousParsingAllowed = val;
}

// Static utility functions

String Forensics::CreateMarkupWithoutChildren(Node* node){
	if (!node)
		return "";
	MarkupAccumulator accumulator(DoNotResolveURLs);
	accumulator.appendStartTag(*node);
	if (node->isElementNode())
        accumulator.appendEndTag(* (toElement(node)));
	return accumulator.toString();
}

double Forensics::secondsToMilliseconds(double timestampSeconds) {
    return timestampSeconds*1000;
}

double Forensics::getCurrentTimeMs() {
    return Platform::current()->currentTime() * 1000;
}

double Forensics::getCurrentTimeSeconds() {
    return Platform::current()->currentTime();
}

WebTaskRunner* Forensics::getTimerTaskRunner() {
    return Platform::current()->currentThread()->scheduler()->timerTaskRunner();
}

const KURL& Forensics::getCurrentURL(LocalFrame* frame) {   
    return frame->document()->url();
}

const KURL& Forensics::getCurrentURL(Document* doc) {   
    return doc->url();
}

const KURL& Forensics::getCurrentURL(ExecutionContext* context) {   
    return context->url();
}

const CString Forensics::getCurrentURLCString(LocalFrame* frame) {
    return toCString(getCurrentURL(frame));
}

Page* Forensics::localFrameToPage(LocalFrame* frame) {
   return frame->document()->page();
}

CString Forensics::toCString(const KURL& url) {   
    return url.string().utf8();
}

CString Forensics::toCString(const String& str) {   
    return str.utf8();
}

CString Forensics::toCString(const String* str) {
    return str->utf8();
}

const char* Forensics::toCharPtr(const WebInputEvent& event) { 
  // Converts inputEvent.type to a string

  const char* event_name = 0;
  switch (event.type) {
    case WebInputEvent::Undefined:
      event_name = "unknown";
      break;

    case WebInputEvent::MouseDown:
      event_name = "MouseDown";
      break;
    case WebInputEvent::MouseUp:
      event_name = "MouseUp";
      break;
    case WebInputEvent::MouseMove:
      event_name = "MouseMove";
      break;
    case WebInputEvent::MouseEnter:
      event_name = "MouseEnter";
      break;
    case WebInputEvent::MouseLeave:
      event_name = "MouseLeave";
      break;
    case WebInputEvent::ContextMenu:
      event_name = "ContextMenu";
      break;

    case WebInputEvent::MouseWheel:
      event_name = "MouseWheel";
      break;

    case WebInputEvent::RawKeyDown:
      event_name = "RawKeyDown";
      break;
    case WebInputEvent::KeyDown:
      event_name = "KeyDown";
      break;
    case WebInputEvent::KeyUp:
      event_name = "KeyUp";
      break;
    case WebInputEvent::Char:
      event_name = "Char";
      break;

    case WebInputEvent::GestureScrollBegin:
      event_name = "GestureScrollBegin";
      break;
    case WebInputEvent::GestureScrollEnd:
      event_name = "GestureScrollEnd";
      break;
    case WebInputEvent::GestureScrollUpdate:
      event_name = "GestureScrollUpdate";
      break;
    case WebInputEvent::GestureFlingStart:
      event_name = "GestureFlingStart";
      break;
    case WebInputEvent::GestureFlingCancel:
      event_name = "GestureFlingCancel";
      break;
    case WebInputEvent::GestureTap:
      event_name = "GestureTap";
      break;
    case WebInputEvent::GestureTapUnconfirmed:
      event_name = "GestureTapUnconfirmed";
      break;
    case WebInputEvent::GestureTapDown:
      event_name = "GestureTapDown";
      break;
    case WebInputEvent::GestureShowPress:
      event_name = "GestureShowPress";
      break;
    case WebInputEvent::GestureTapCancel:
      event_name = "GestureTapCancel";
      break;
    case WebInputEvent::GestureDoubleTap:
      event_name = "GestureDoubleTap";
      break;
    case WebInputEvent::GestureTwoFingerTap:
      event_name = "GestureTwoFingerTap";
      break;
    case WebInputEvent::GestureLongPress:
      event_name = "GestureLongPress";
      break;
    case WebInputEvent::GestureLongTap:
      event_name = "GestureLongTap";
      break;
    case WebInputEvent::GesturePinchBegin:
      event_name = "GesturePinchBegin";
      break;
    case WebInputEvent::GesturePinchEnd:
      event_name = "GesturePinchEnd";
      break;
    case WebInputEvent::GesturePinchUpdate:
      event_name = "GesturePinchUpdate";
      break;

    case WebInputEvent::TouchStart:
      event_name = "TouchStart";
      break;
    case WebInputEvent::TouchMove:
      event_name = "TouchMove";
      break;
    case WebInputEvent::TouchEnd:
      event_name = "TouchEnd";
      break;
    case WebInputEvent::TouchCancel:
      event_name = "TouchCancel";
      break;
    default:
      WTF_LOG(Forensics,"InspectorForensicsAgent::eventTypeString : WARNING: Received unexpected event type: %d", event.type);
      event_name = "unknown";
      break;
  }

  return event_name;

}


Element* Forensics::eventTarget(LocalFrame* frame, const WebInputEvent& inputEvent) {

    if(WebInputEvent::isMouseEventType(inputEvent.type)) 
        return mouseEventTarget(frame, inputEvent);
    else if(WebInputEvent::isKeyboardEventType(inputEvent.type))
        return keyEventTarget(frame, inputEvent);

    return nullptr;

}


Element* Forensics::keyEventTarget(LocalFrame* frame, const WebInputEvent& inputEvent) {
    ASSERT(frame);
    ASSERT(frame->document());
    
    Node* node = eventTargetNodeForDocument(frame->document());
    if(node)
        return toElement(node);

    return nullptr;
}


Element* Forensics::mouseEventTarget(LocalFrame* frame, const WebInputEvent& inputEvent) {
    ASSERT(frame);
    ASSERT(frame->document());

    IntPoint point(static_cast<const WebMouseEvent&>(inputEvent).x, static_cast<const WebMouseEvent&>(inputEvent).y);
    HitTestResult htr;
    LocalFrame* targetFrame = frame;

    do {

        frame = targetFrame;
        mouseEventHitTestResult(frame, point, htr);

        if (htr.innerNode()) {

            // TODO(Roberto): we currently do not suport ImageMap; we need to add this in the future
            // Frame* f = htr.innerNodeOrImageMapImage()->document().frame();
            // targetFrame = toLocalFrame(f);
            // ...

            Node* node = htr.innerNode();
            if (node && node->isElementNode()) {
                if(node->isFrameOwnerElement() && toHTMLFrameOwnerElement(node)->contentFrame()) {
                    Frame* f = toHTMLFrameOwnerElement(node)->contentFrame();
                    targetFrame = toLocalFrame(f);
                }
            }

        }

        // update coordinates if needed
        if(targetFrame != frame) {
            point.setX(htr.localPoint().x().toInt());
            point.setY(htr.localPoint().y().toInt());
        }

    } while(targetFrame != frame);

    return htr.innerElement();
}

void Forensics::mouseEventHitTestResult(LocalFrame* frame, IntPoint point, HitTestResult& htr) {

    // code borrowed from EventHandler:
    // prepareMouseEvent(const HitTestRequest& request, const PlatformMouseEvent& mev)
    // contentPointFromRootFrame(LocalFrame* frame, const IntPoint& pointInRootFrame)

    // static_cast<const WebMouseEvent&>(inputEvent)

    /*
    if(!view) return nullptr; 
    view->rootFrameToContents(pointInRootFrame);
    */

    Document* doc = frame->document();

    // code borrowed from Document
    // Document::prepareMouseEvent(...)

    ASSERT(!doc->layoutView() || doc->layoutView()->isLayoutView());

    // LayoutView::hitTest causes a layout, and we don't want to hit that until the first
    // layout because until then, there is nothing shown on the screen - the user can't
    // have intentionally clicked on something belonging to this page. Furthermore,
    // mousemove events before the first layout should not lead to a premature layout()
    // happening, which could show a flash of white.
    // See also the similar code in EventHandler::hitTestResultAtPoint.
    if (!doc->layoutView() || !doc->view() || !doc->view()->didFirstLayout()) {
        // HitTestResult hr = HitTestResult(request, LayoutPoint());
        // return hr.innerElement();
        return;
    }

    HitTestRequest htRequest(HitTestRequest::ReadOnly);
    HitTestResult result(htRequest, point);
    doc->layoutView()->hitTest(result);

    htr = result;
}



} // namespace blink

