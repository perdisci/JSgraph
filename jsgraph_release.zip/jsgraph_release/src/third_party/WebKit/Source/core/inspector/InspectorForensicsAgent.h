/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/

#ifndef InspectorForensicsAgent_h
#define InspectorForensicsAgent_h

#include "core/CoreExport.h"
#include "core/InspectorFrontend.h"
#include "core/inspector/InspectorBaseAgent.h"
#include "core/inspector/InspectorPageAgent.h"
#include "wtf/Noncopyable.h"
#include "wtf/PassOwnPtr.h"
#include "wtf/text/WTFString.h"
#include "platform/weborigin/KURL.h"
#include "core/inspector/forensics/ForensicDataStore.h"
#include "core/inspector/forensics/ForensicReplayEngine.h"
//#include "core/inspector/forensics/ForensicInputEvent.h"
#include "core/inspector/forensics/ForensicPlatformRecorder.h"
#include "core/css/CSSImageValue.h"
#include "wtf/LinkedStack.h"




namespace ForensicsAgentState {
static const char forensicsAgentEnabled[] = "forensicsAgentEnabled";
};

namespace blink {

class Node;
class Document;
class LocalFrame;
class WebInputEvent;
class HitTestResult;
class Event;
class EventTarget;
class EventListener;
class ScheduledAction;
class ExecutionContext;
class ForensicXHRDataStore;
class CharacterData;
class FrameRequestCallback;
class DocumentLoader;
class IdleRequestCallback;
class MutationObserver;

typedef String ErrorString;

class CORE_EXPORT InspectorForensicsAgent final : public InspectorBaseAgent<InspectorForensicsAgent, InspectorFrontend::Forensics>, public InspectorBackendDispatcher::ForensicsCommandHandler {
    WTF_MAKE_NONCOPYABLE(InspectorForensicsAgent);
public:

    static PassOwnPtrWillBeRawPtr<InspectorForensicsAgent> create(LocalFrame* inspectedFrame, InspectorPageAgent* pageAgent)
    {   
        return adoptPtrWillBeNoop(new InspectorForensicsAgent(inspectedFrame, pageAgent));
    }

    ~InspectorForensicsAgent() override;
    DECLARE_VIRTUAL_TRACE();

    // Agent Control
    void restore();
    bool enabled() const;
    void enableAsynchronousParsing();
    void disableAsynchronousParsing();
    void enableTakeDOMTextSnapshot();
    void disableTakeDOMTextSnapshot();
    void enableJavaScript();
    void disableJavaScript();

    // Commands
    void enable(ErrorString*);
    void disable(ErrorString*);
    void startRecording(ErrorString*);
    void stopRecording(ErrorString*);    
    void startReplay(ErrorString*);
    void stopReplay(ErrorString*);    
    void enableAsynchronousParsing(ErrorString*);
    void disableAsynchronousParsing(ErrorString*);
    void enableTakeDOMTextSnapshot(ErrorString*);
    void disableTakeDOMTextSnapshot(ErrorString*);
    void enableJavaScript(ErrorString*);
    void disableJavaScript(ErrorString*);

    // Hooks
    void didInsertDOMNode(Node*);
    void didInsertDOMNodeForensics(Node* node);
    void characterDataModified(CharacterData*);
    void willRemoveDOMNode(Node* node);
    void willModifyDOMAttrForensics(Element*, const QualifiedName& name, const AtomicString& Value); //test
    void didModifyDOMAttr(Element* element, const QualifiedName& name, const AtomicString& value);
    void didRemoveDOMAttr(Element* element, const QualifiedName& name);
	void didInvalidateStyleAttr(Node* node);
	void didPushShadowRoot(Element* host, ShadowRoot*);
    void didStartProvisionalLoadForensics(LocalFrame*, const KURL& requestURL);
    void receivedMainResourceRedirectForensics(LocalFrame*, const KURL& newURL);
    void frameAttachedToParent(LocalFrame*);
    void willHandleEvent(EventTarget*, Event*, EventListener* listener, bool useCapture);
    void willSendXMLHttpRequest(const String& url);
    bool handleCreateChildFrameLoaderForensics(LocalFrame*, const KURL& url);
    void handleCreateChildFrameLoaderEndForensics(LocalFrame*, const KURL& url);
    void handleInputEventForensics(LocalFrame*, const WebInputEvent&);
    void handleRunCompiledScriptStartForensics(ExecutionContext*, int scriptId, bool& m_enableJavaScript);
    void handleRunCompiledScriptEndForensics(int scriptId);
    void handleCompileScriptForensics(v8::Local<v8::String> code, int scriptId, const KURL& url, const TextPosition& startposition);    
    void handleCallFunctionStartForensics(ExecutionContext*,v8::MaybeLocal<v8::Function> function, bool& m_enableJavaScript);
    void handleCallFunctionEndForensics(v8::MaybeLocal<v8::Function> function);
    void handleGetElementByIdForensics(Node*);
    //void handleGetElementByClassNameForensics(Node*);
    bool handleAddEventListenerForensics(EventTarget*, const AtomicString& eventType, PassRefPtr<EventListener> listener, bool useCapture);
	int  handleDOMTimerInstallEventReplay(ExecutionContext* context, PassOwnPtr<ScheduledAction> action);
	void handleDOMTimerInstallEventRecording(ExecutionContext* context, ScheduledAction* action, int timeoutID);
	void handlewillFireTimerEvent(ExecutionContext* context, ScheduledAction* action, int  timeoutID, bool singleShot);
	bool handleGetXHRDataStatusForensics(int& data);
	bool handleGetXHRDataReadyStateForensics(int& data);
	bool handleGetXHRDataResponseTextForensics(ScriptString& data);
	bool handleGetXHRDataOpenForensics(bool& data);
	bool handleGetXHRDataResponseTypeCodeForensics(int& data);
	void handleRecordXHRDataStatusForensics(int data);
	void handleRecordXHRDataReadyStateForensics(int data);
	void handleRecordXHRDataResponseTextForensics(ScriptString data);
	void handleRecordXHRDataOpenForensics(bool data);
	void handleRecordXHRDataResponseTypeCodeForensics(int data);
	void handleEvaluateScriptInMainWorldForensics(ExecutionContext*, const ScriptSourceCode&  sourceCode, int accessControlStatus, bool policy);
	void handleRecordCookieForensics(LocalFrame*, const String& cookieString, const String& exceptionStateString);
	bool handleGetCookieForensics(LocalFrame*, String& cookieString, String& exceptionStateString);
	void handleRecordSetCookieForensics(LocalFrame*, const String& exceptionStateString);
	bool handleGetSetCookieForensics(LocalFrame*, String& exceptionStateString);
	bool handleDocumentWriteStart(LocalFrame*, bool& hasInsertionPoint, const SegmentedString& text);
	void handleDocumentWriteEnd(LocalFrame*, bool hasInsertionPoint);
	void handleCharacterDataPaserAppendDataForensics(CharacterData*, const String& data);
	bool handleDocumentReadyStateReplaying(String& readyState);
	void handleDocumentReadyStateRecording(const String& readyState);
	bool handleGetCSSItemForensics(unsigned i, String& data);
	void handleSetCSSItemForensics(unsigned i, const String& data);
	void handleSetCSSLengthForensics(unsigned length);
	bool handleGetCSSLengthForensics(unsigned& length);
	void handleSetCSSGetPropertyValueForensics(const String& data);
	bool handleGetCSSGetPropertyValueForensics(String& data);
	void handleSetCSSGetPropertyPriorityForensics(const String& data);
	bool handleGetCSSGetPropertyPriorityForensics(String& data);
	bool handleGetEventTimeStampForensics(double& timeStamp);
	void handleSetEventTimeStampForensics(double timeStamp);
	bool handleRegisterFrameRequestCallbackForensics(FrameRequestCallback*  callback, int& id);
	void handlExecuteFrameRequestCallbackEventForensics(ExecutionContext*, FrameRequestCallback*  callback, int id, double highResNowMs);
	bool handleDynamicScriptExecutionStartForensics(Element*);
	void handleDynamicScriptExecutionEndForensics(Element*);
	void handleScrollIntoViewIfNeededForensics(Element*, bool centerIfNeeded);
	void handleScrollIntoViewForensics(Element*, bool alignToTop);
	void handleRequestFullscreenForensics(Element*, bool hasPrefix);
	void handleExitFullscreenForensics(Document*);
	void handleRecordXHRSetRequestHeaderForensics(const AtomicString& name, const AtomicString& value);
	void handleRecordElementFocusForensics(Element*);
	void handleRecordElementBlurForensics(Element*);
	void handleRecordWindowScrollToXYForensics(LocalFrame*, double x, double y);
	void handleRecordSetLocationForensics(LocalFrame*, const String& url);
	void handleRecordSubmitFromJavaScript(Element*);
	void handleRecordHistoryStateObjectAdded(LocalFrame*, const String& urlString, unsigned type);
	void handleRecordHTMLMediaElementLoad(Element*);
	void handleRecordHTMLMediaElementPlayForensics(Element*);
	void handleRecordRegisterIdleTaskCallback(IdleRequestCallback* callback, int id, long long timeoutMillis);
	void handleRecordIdleTaskCallbackFiredForensics(int id, double deadlineSeconds, unsigned callbackType);
	void handleRecordRegisterMutationObserverForensics(Node*, MutationObserver* observer, unsigned char options, const HashSet<AtomicString>& attributeFilter);
	void willDeliverMutationRecords(ExecutionContext*, MutationObserver* observer);
    void handleModaldialogConfirmResultRecording(const String& message, bool result);
    void handleModaldialogPromptResultRecording(const String& message, const String& result);
    void handleModaldialogAlertRecording(const String& message);
    void handleWindowOpenForensics(const String& urlString, const AtomicString& frameName, const String& windowFeaturesString);
    void handleHandleClickForensics(const KURL& url);
    void handleWindowFocusForensics(LocalFrame* frame);
    void handleWindowBlurForensics(LocalFrame* frame);
    void willCloseWindow();
    void handleDocumentDispatchUnloadEventsForensics();
    void handleMaybeHandleHttpRefreshForensics(LocalFrame* frame, const String& refreshURL, double delay);
    

	
	//Trace_Event Hooks
	void domContentLoadedEventFired(LocalFrame*);
	void loadEventFired(LocalFrame*);
	void didCommitLoad(LocalFrame*, DocumentLoader*);
	void frameStoppedLoading(LocalFrame*);
	void frameScheduledNavigation(LocalFrame*, double delay);
	void willInsertDOMNode(Node* parent);

private:
    InspectorForensicsAgent(LocalFrame* inspectedFrame, InspectorPageAgent* pageAgent);

    bool recording();
    bool replaying();
    void resetAgentState();
    void createDataStore();
    void wrapPlatformForRecording();
    void unwrapPlatformAfterRecording();

    // Agent control
    void innerEnable();

    // Agent state
    bool m_recording;
    bool m_replaying;
    double m_recordingStartTime;
    int m_inJSCounter;
    int m_inDocumentWriteCounter;

    // Internal methods
    Element* mouseEventTarget(LocalFrame* frame, const WebInputEvent& inputEvent);
    void mouseEventHitTestResult(LocalFrame* frame, IntPoint point, HitTestResult& htr);
    void takeDOMTextSnapshot(LocalFrame* frame, String& domSnapshot, double timestamp);
    void frameContentAsPlainText(LocalFrame* frame, String& output);
    void logFrameContent();
    bool isJSInsertedFrameNode(Node*);
    bool isJSInsertedFrameContext(ExecutionContext*);
    String getParentChain(Node* node, int level = 4);
    int getCurrentScriptHash(){return m_scirptHashStack.isEmpty()? 0 : m_scirptHashStack.peek();}
    bool isRecordEventInJS();

    
    RawPtrWillBeMember<InspectorPageAgent> m_pageAgent;
    RawPtrWillBeMember<LocalFrame> m_inspectedFrame;
    RawPtrWillBeMember<LocalFrame> m_mainFrame;
    RefPtrWillBeMember<Document> m_document;

    Platform* m_blinkPlatform;
    RefPtr<ForensicPlatformRecorder> m_forensicPlatformRecorder;
    RefPtr<ForensicDataStore> m_dataStore;
    //RefPtr<ForensicReplayEngine> m_replayEngine;
    LinkedStack<Document*> m_JSDocumentStack;
    HashMap<int, int> m_scriptId2HashMap;
    HashMap<long, int> m_node2BackgroundImageHashMap;
    LinkedStack<int> m_scirptHashStack;
    LinkedStack<bool> m_RecordEventInJSStack;
    LinkedStack<int> m_dynamicScriptExecutionCountStack;
    //This is used to see whether we need to record the node inserted in document.write. If the node
    // is inserted by a script which was inserted by document.write, we will not record such node.

    KURL m_initialPageURL;

};


} // namespace blink

#endif // !defined(InspectorForensicsAgent_h)