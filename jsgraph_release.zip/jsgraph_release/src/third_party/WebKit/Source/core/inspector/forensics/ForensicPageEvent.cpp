/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/

#include "config.h"
#include "core/inspector/forensics/ForensicPageEvent.h"
#include "platform/weborigin/KURL.h"

namespace blink {

ForensicPageEvent::ForensicPageEvent(const KURL& pageURL, const double timeStampMs)
    : ForensicEvent(timeStampMs)
    , m_pageURL(pageURL)
{
}

const KURL& ForensicPageEvent::pageURL() {
    return m_pageURL;
}


} // namespace blink
