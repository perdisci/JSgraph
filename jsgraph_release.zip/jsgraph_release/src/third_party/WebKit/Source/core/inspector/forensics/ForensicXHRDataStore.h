#ifndef ForensicXHRDataStore_h
#define ForensicXHRDataStore_h

#include "wtf/ThreadSafeRefCounted.h"
#include "wtf/PassRefPtr.h"
#include "bindings/core/v8/ScriptString.h"


namespace blink {


class ForensicXHRDataStore : public ThreadSafeRefCounted<ForensicXHRDataStore> {

public:
	static PassRefPtr<ForensicXHRDataStore> create(bool data);
    static PassRefPtr<ForensicXHRDataStore> create(int data);
    static PassRefPtr<ForensicXHRDataStore> create(ScriptString data);
    bool getBoolDataStore();
    int getIntDataStore();
    ScriptString getScriptStringDataStore();
    
    ~ForensicXHRDataStore(){};

private:
	ForensicXHRDataStore(bool data);
    ForensicXHRDataStore(int data);
    ForensicXHRDataStore(ScriptString data);
    bool m_boolDataStore;
    int m_intDataStore;
    ScriptString m_scriptStringDataStore;
    



}; // class ForensicXHRDataStore

} // namespace blink

#endif /* ForensicXHRDataStore_h */