/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/

#include "config.h"
#include "core/inspector/forensics/ForensicDataStore.h"
#include "core/inspector/forensics/Forensics.h"
#include "core/editing/serializers/Serialization.h"
#include "core/dom/Node.h"
#include "core/dom/Document.h"
#include "core/dom/FrameRequestCallback.h"
#include "core/events/MouseEvent.h"
#include "core/events/KeyboardEvent.h"
#include "core/events/TouchEvent.h"
#include "core/events/GestureEvent.h"
#include "core/events/PointerEvent.h"
#include "core/events/MessageEvent.h"

//Phani
#include "public/platform/WebFileUtilities.h"
//Phani


namespace blink {

PassRefPtr<ForensicDataStore> ForensicDataStore::create() {
    return adoptRef(new ForensicDataStore());
}

ForensicDataStore::ForensicDataStore() {
    m_nextEventIndex = 0;
    m_currentDOMEventIndex = 0;
    m_lastEventIndex = 0;
    m_nextStarted = false;
    m_nextEventListenerIndex = 0;
    m_nextDomTimerIndex = 0;
    m_nextXHRIndex = 0;
    m_nextFrameIndex = 0;
    m_cookieStringIndex = 0;
    m_exceptionStateStringsSetCookieIndex = 0;
    m_hasInsertionPointIndex = 0;
    m_documentReadyStateIndex = 0;
    m_nextCSSIndex = 0;
    m_nextEventTimeStampIndex = 0;
    m_nextFrameRequestCallbackIndex = 0;
    m_nextDynamicScriptExecutionCountIndex = 0;
}

void ForensicDataStore::recordInsertDOMNodeEvent(Document* doc, Node* node)
{
	Node* nextSibling = node->nextSibling(); 

	m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordInsertDOMNodeEvent: m_selfNode: ",std::to_string((long) node),", m_parentNode: ",std::to_string((long) node->parentNode()),", m_nextsibling: ",std::to_string((long) nextSibling),", m_nodeSource: ",  (createMarkup(node)).latin1().data());

}

void ForensicDataStore::recordPageLoadEvent(LocalFrame* frame, const KURL& requestURL)
{
	m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordPageLoadEvent : frame: ",std::to_string((long) frame),", requestURL: ", requestURL.string().latin1().data());

}

void ForensicDataStore::recordChildFrame(LocalFrame* frame, const KURL& url)
{
	m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordChildFrame : requestURL: ",url.string().latin1().data(),", frame: ", std::to_string((long) frame));
}

void ForensicDataStore::recordFireEventListenerEvent(LocalFrame* frame, EventTarget* eventTarget, Event* event, EventListener* listener, bool useCapture, bool isRecordEventInJS)
{
	m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordFireEventListenerEvent : EventTarget: ",std::to_string((long) eventTarget),", Event Listener: ",std::to_string((long)listener),", Event type: ",String(event->type()).latin1().data(),", Event interface name: ",String(event->interfaceName()).latin1().data(),", CurrentTarget:",std::to_string((long) event->currentTarget()),", Target:" , std::to_string((long) event->target()));
	if (event->isMouseEvent()){
		MouseEvent* new_event = static_cast<MouseEvent*>(event);
		m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordFireEventListenerEvent : clientX: ",std::to_string(new_event->clientX()), ", clientY: ",std::to_string(new_event->clientY()),", relatedTarget: ", std::to_string((long) new_event->relatedTarget()));
	}
	else if(event->isPointerEvent()){
		PointerEvent* new_event = static_cast<PointerEvent*>(event);
		m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordFireEventListenerEvent : clientX: ",std::to_string(new_event->clientX()),", clientY: ",std::to_string(new_event->clientY()),", relatedTarget: ", std::to_string((long) new_event->relatedTarget()));
	}
	else if(event->isGestureEvent()){
		GestureEvent* new_event = static_cast<GestureEvent*>(event);
		m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordFireEventListenerEvent : clientX: ", std::to_string(new_event->clientX()),", clientY: ", std::to_string(new_event->clientY()));
	}
	else if(event->isKeyboardEvent()){
		KeyboardEvent* new_event = static_cast<KeyboardEvent*>(event);
		m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordFireEventListenerEvent : keyCode: ", std::to_string(new_event->keyCode()));
	}
	else if(event->type() == EventTypeNames::message){
		MessageEvent* new_event = static_cast<MessageEvent*>(event);
		m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordFireEventListenerEvent : Origin: ", new_event->origin().latin1().data(), ", Message: ", new_event->dataAsSerializedScriptValue()->toWireString().utf8().data());

	}
}

void ForensicDataStore::recordInstallDOMTimerEvent(ExecutionContext* context, ScheduledAction* action, int timeoutID){
	m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordInstallDOMTimerEvent : ExecutionContext: ",std::to_string((long) context),", ScheduledAction: ",std::to_string((long) action),", timeoutID: ", std::to_string(timeoutID));

}

void ForensicDataStore::recordFireDOMTimerEvent(LocalFrame* frame, ExecutionContext* context, ScheduledAction* action, int timeoutID,  bool singleShot){
    m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordFireDOMTimerEvent : frame: ",std::to_string((long) frame),", ExecutionContext: ",std::to_string((long) context),", ScheduledAction: ",std::to_string((long) action),", timeoutID: ",std::to_string(timeoutID),", singleShot: ", std::to_string(singleShot));

}

void ForensicDataStore::recordInputEvent(LocalFrame* mainFrame, const WebInputEvent& inputEvent) {
    //To be released
}

void ForensicDataStore::recordImage(Document* doc,Node* node){
	//NOTE: output image data
	m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordImage : node: ", std::to_string((long) node));

}

void ForensicDataStore::recordXHRDataStore(PassRefPtr<ForensicXHRDataStore> data){
	//To be released
}

void ForensicDataStore::recordCSSDataStore(PassRefPtr<ForensicCSSDataStore> data){
	//To be released
}

PassRefPtr<ForensicImageDataStore> ForensicDataStore::getImage(Node* node){
	//To be released
}

void ForensicDataStore::recordEvaluateScriptInMainWorldEvent(ExecutionContext* context, const ScriptSourceCode&  sourceCode, int accessControlStatus, bool policy, bool isRecordEventInJS){
	//To be released
}

void ForensicDataStore::recordCharacterDataPaserAppendDataEvent(LocalFrame* frame, Node* node, const String& data){
    m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordCharacterDataPaserAppendDataEvent : frame: ",std::to_string((long) frame),", Node: ",std::to_string((long) node),", Data: ", data.latin1().data());

}

void ForensicDataStore::recordCookieDataStore(const String& cookieString, const String& exceptionStateString){
	m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordCookieDataStore : cookieString: ", cookieString.latin1().data());
}

void ForensicDataStore::recordEventTimeStampDataStore(double timestamp){
	m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordEventTimeStampDataStore : timestamp: ", std::to_string(timestamp));
}


void ForensicDataStore::recordSetCookieDataStore(const String& exceptionStateString){
	//To be released
}

void ForensicDataStore::recordDocumentWriteDataStore(bool hasInsertionPoint){
	//To be released
}

void ForensicDataStore::recordDocumentReadyState(const String& readyState){
	m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordDocumentReadyState : readyState: ", readyState.latin1().data());

}

void ForensicDataStore::recordRegisterFrameRequestCallbackEvent(FrameRequestCallback* callback, int id){
	m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordRegisterFrameRequestCallbackEvent : callback: ",std::to_string((long) callback),", id: ", std::to_string(id));
}

void ForensicDataStore::recordExecuteFrameRequestCallbackEvent(ExecutionContext* context, FrameRequestCallback* callback, int id, double highResNowMs){
	m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordExecuteFrameRequestCallbackEvent : callback: ",std::to_string((long) callback),", id: ",std::to_string(id),", highResNowMs: ", std::to_string(highResNowMs));

}

void ForensicDataStore::recordDynamicScriptExecutionCount(int dynamicScriptExecutionCount, bool isDumpCountStack){
    //To be released
}

void ForensicDataStore::appendForensicEvent(PassRefPtr<ForensicEvent> event) {
    //To be released
}

void ForensicDataStore::appendForensicDOMEvent(PassRefPtr<ForensicDOMEvent> event){
    //To be released   
}

void ForensicDataStore::recordAddEventListenerEvent(EventTarget* eventTarget, EventListener* listener){
	m_blinkPlatform->fileUtilities()->tab_log_combine("ForensicDataStore::recordAddEventListenerEvent : eventTarget: ",std::to_string((long)eventTarget),", listener: ", std::to_string((long)listener));

}


//NOTE (Bo): m_currentDOMEventIndex means the index is going to be replayed but haven't
PassRefPtr<ForensicDOMEvent> ForensicDataStore::currentAvailableForensicDOMEvent(){
    //To be released
}

PassRefPtr<ForensicDOMEvent> ForensicDataStore::nextAvailableForensicDOMEvent() {
    //To be released
}

PassRefPtr<ForensicDOMEvent> ForensicDataStore::findNextDoctypeForensicDOMEvent() {
    //To be released
}

PassRefPtr<ForensicDOMEvent> ForensicDataStore::findNextHtmlForensicDOMEvent() {
    //To be released
}

PassRefPtr<ForensicDOMEvent> ForensicDataStore::findNextHeadForensicDOMEvent() {
    //To be released
}

PassRefPtr<ForensicDOMEvent> ForensicDataStore::findNextBodyForensicDOMEvent() {
    //To be released
}

bool ForensicDataStore::isWillSkipForensicDOMEvent(PassRefPtr<ForensicDOMEvent> event){
    //To be released
}

bool ForensicDataStore::isInProgressingOfReplayingIframe(){
    //To be released
}


PassRefPtr<ForensicEvent> ForensicDataStore::nextAvailableForensicEvent() {
    //To be released
}

void ForensicDataStore::nextEventListenerInfo(long &eventTargetIndex, long &eventListenerIndex){
    //To be released
}

void ForensicDataStore::nextDomTimerInfo(long &domTimerContextIndex, long &domTimerActionIndex, int &domTimerTimeoutID){
    //To be released
}


void ForensicDataStore::nextCookieDataStore(String& cookieString, String& exceptionStateString){
    //To be released
}

String ForensicDataStore::nextSetCookieDataStore(){
    //To be released
}

String ForensicDataStore::nextDocumentReadyState(){
    //To be released
}

double ForensicDataStore::nextEventTimeStampDataStore(){
    //To be released
}

PassRefPtr<ForensicXHRDataStore> ForensicDataStore::nextXHRDataStore(){
    //To be released
}

PassRefPtr<ForensicCSSDataStore> ForensicDataStore::nextCSSDataStore(){
    //To be released
}

bool ForensicDataStore::nextHasInsertionPoints(){
    //To be released
}

void ForensicDataStore::nextFrameRequestCallback(long& callback, int& id){
    //To be released
}

long ForensicDataStore::nextFrame(){
    //To be released
}

int ForensicDataStore::nextDynamicScriptExecutionCount(){
    //To be released
}

} // namespace blink
