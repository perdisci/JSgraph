#ifndef ForensicCSSDataStore_h
#define ForensicCSSDataStore_h

#include "wtf/ThreadSafeRefCounted.h"
#include "wtf/PassRefPtr.h"
#include "wtf/text/WTFString.h"


namespace blink {


class ForensicCSSDataStore : public ThreadSafeRefCounted<ForensicCSSDataStore> {

public:
	static PassRefPtr<ForensicCSSDataStore> create(unsigned i, const String& data);

    unsigned getIntDataStore();
    String getStringDataStore();
    
    ~ForensicCSSDataStore(){};

private:
	ForensicCSSDataStore(unsigned i, const String& data);

    unsigned m_intDataStore;
    String m_stringDataStore;
    



}; // class ForensicCSSDataStore

} // namespace blink

#endif /* ForensicCSSDataStore_h */