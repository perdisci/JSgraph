#include "config.h"
#include "core/inspector/forensics/ForensicEvent.h"

namespace blink {

ForensicEvent::ForensicEvent(double timeStampMs)
        : m_timestamp(timeStampMs)
{
}

double ForensicEvent::timeStampMs() {
    return m_timestamp;
}

} // namespace blink

