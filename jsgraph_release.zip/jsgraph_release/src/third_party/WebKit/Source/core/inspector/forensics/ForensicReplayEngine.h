/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/

#ifndef ForensicReplayEngine_h
#define ForensicReplayEngine_h

#include "wtf/PassRefPtr.h"
#include "wtf/RefCounted.h"
#include "core/inspector/InspectorPageAgent.h"
#include "core/inspector/forensics/ForensicDataStore.h"
#include "core/events/RegisteredEventListener.h"

namespace blink {

class WebInputEvent;
class Node;
class Document;
class EventTarget;
class EventListener;
class ExecutionContext;
class ScheduledAction;
class FrameRequestCallback;


class ForensicReplayEngine : public RefCounted<ForensicReplayEngine> {

public:
    static PassRefPtr<ForensicReplayEngine> create(LocalFrame* mainFrame, InspectorPageAgent* pageAgent, PassRefPtr<ForensicDataStore> dataStore, double recordingStartTime);

    void startReplay();
    void handledInputEvent(LocalFrame* frame, const WebInputEvent& event);
    void handleInsertDOMNodeEvent(LocalFrame* frame, Node* node);
    void handleEvaluateScriptInMainWorldEvent(LocalFrame* frame);
	void handleFireEventListenerEvent(LocalFrame* frame);
	void handleExecuteFrameRequestCallbackEvent(LocalFrame* frame);
	void handleDOMTimerEvent(LocalFrame* frame);
    int handleGetXHRDataResponseTypeCodeForensics();
    int handleGetXHRDataStatusForensics();
	int handleGetXHRDataReadyStateForensics();
	void handleCreateChildFrameLoader(LocalFrame* frame, const KURL& url);
	void handleDidStartProvisionalLoad(LocalFrame* frame);
	ScriptString handleGetXHRDataResponseTextForensics();
	bool handleGetXHRDataOpenForensics();
	String handleGetCSSItemForensics(unsigned i);
	unsigned handleGetCSSLengthForensics();
	String handleGetCSSGetPropertyValueForensics();
	String handleGetCSSGetPropertyPriorityForensics();
    void handleAddEventListener(EventTarget* eventTarget, PassRefPtr<EventListener> listener, bool useCapture);
    int handleInstallDomTimer(ExecutionContext* context, PassOwnPtr<ScheduledAction> action);
    void handleGetCookieForensics(String& cookieString, String& exceptionStateString);
    void handleGetSetCookieForensics(String& exceptionStateString);
    void handleDocumentWriteStart(bool& hasInsertionPoint, const SegmentedString& text);
    void handleCharacterDataPaserAppendDataEvent(LocalFrame* frame, Node*, const String& data);
    void handleDocumentReadyStateReplaying(String& readyState);
    double handleGetEventTimeStampForensics();
    void handleRegisterFrameRequestCallback(FrameRequestCallback* callback, int& id);
    void handleDynamicScriptExecutionStartForensics(LocalFrame*);
    
    void clearLastInjectedNode();
    void clearNodeMap();
    void clearCallbackMaps();
    void clearFrameMap();
    
    LocalFrame* getMatchedLocalFrame(Frame* frame);
    String getNextPageStarter();
    void loadNextRecordedPagewithURL(LocalFrame* frame, const KURL& url);
    
    HashMap<long, RefPtr<Node>> m_nodeMap;
    HashMap<long, RefPtr<EventTarget>> m_eventTargetMap;
    //HashMap<long, Persistent<RegisteredEventListener>> m_eventListenerMap;
    HashMap<long, RefPtrWillBeMember<EventListener>> m_eventListenerMap;
    HashMap<long, OwnPtr<ScheduledAction>> m_domTimerActionMap;
    HashMap<long, RefPtr<ExecutionContext>> m_domTimerContextMap;
    HashMap<long, RefPtr<LocalFrame>> m_frameMap;
    HashMap<long, Persistent<FrameRequestCallback>> m_frameRequestCallbackMap;

    // utility
    static void loadPage(LocalFrame* frame, const KURL& url);
    static void cleanMemoryCache(LocalFrame* frame);
    static void doCleanCacheAndReloadPage(LocalFrame* frame, const KURL& url);
    

private:
    ForensicReplayEngine(LocalFrame* mainFrame, InspectorPageAgent* pageAgent, PassRefPtr<ForensicDataStore> dataStore, double recordingStartTime);

    void replayNextEvent(bool delayed = true);
    bool replayNextDOMEvent(Document* doc);
    double computeEventInjectionDelay(double nextEventRecordTime);
    bool isLastDOMEventReplayComplied(const String &currentNodeSource, Node* node);
    String getFormatedString(String &currenNodeSource);
    
    LocalFrame* m_mainFrame;
    InspectorPageAgent* m_pageAgent;
    RefPtr<ForensicDataStore> m_dataStore;
    double m_recordingStartTime; // milliseconds
    double m_replayingStartTime; // milliseconds
    double m_lastReplayedEventRecordTime; // the recorded timestamp of the last replayed event
    Node* m_lastInjectedNode;
    bool m_isFinalDivInjection;
    String m_lastInjectedNodeSource;
    Node* m_lastInsertedScript;
    
    

}; // class ForensicReplayEngine

} // namespace blink

#endif // ForensicReplayEngine_h
