#ifndef ForensicEvent_h
#define ForensicEvent_h

#include "wtf/ThreadSafeRefCounted.h"

namespace blink {

class ForensicEventVisitor;

class ForensicEvent : public ThreadSafeRefCounted<ForensicEvent> {

public:
    virtual ~ForensicEvent(){};
    virtual double timeStampMs() final;
    virtual void accept(ForensicEventVisitor& visitor) = 0;

protected:
    ForensicEvent(double timeStampMs);

private:
    double m_timestamp; // milliseconds

}; // class ForensicEvent

} // namespace blink

#endif /* ForensicEvent_h */
