#ifndef ForensicEventVisitor_h
#define ForensicEventVisitor_h

namespace blink {

class ForensicInputEvent;
class ForensicLoadURLEvent;

class ForensicEventVisitor {

public:
    virtual ~ForensicEventVisitor(){};    

    // url loading
    virtual void visit(ForensicLoadURLEvent& event) = 0;

    // user input
    virtual void visit(ForensicInputEvent& event) = 0;

}; // class ForensicEventVisitor

} // namespace blink

#endif // ForensicEventVisitor_h
