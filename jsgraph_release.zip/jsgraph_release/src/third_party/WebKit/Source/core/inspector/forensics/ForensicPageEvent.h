/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/

#ifndef ForensicPageEvent_h
#define ForensicPageEvent_h

#include "core/inspector/forensics/ForensicEvent.h"
#include "platform/weborigin/KURL.h"

namespace blink {

class ForensicEventVisitor;

class ForensicPageEvent : public ForensicEvent {

public:
    virtual ~ForensicPageEvent(){};
    virtual const KURL& pageURL() final;
    
protected:
    ForensicPageEvent(const KURL& pageURL, const double timeStampMs);

    virtual void accept(ForensicEventVisitor& visitor) = 0;

private:
    KURL m_pageURL;

}; // class ForensicPageEvent

} // namespace blink

#endif // ForensicPageEvent_h
