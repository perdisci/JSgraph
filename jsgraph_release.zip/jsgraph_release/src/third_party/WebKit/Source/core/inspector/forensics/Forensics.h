#ifndef Forensics_h
#define Forensics_h

#include "wtf/text/WTFString.h"
#include "platform/Logging.h"

namespace blink {

class KURL;
class Page;
class Element;
class Document;
class LocalFrame;
class WebTaskRunner;
class WebInputEvent;
class HitTestResult;
class IntPoint;
class ExecutionContext;
class Node;
 
class Forensics {

public:

    static bool isJavaScriptAllowed();
    static void setIsJavaScriptAllowed(bool val);

    static bool isAsynchronousParsingAllowed();
    static void setIsAsynchronousParsingAllowed(bool val);
    
    static bool isTakeDOMTextSnapshotAllowed();
    static void setIsTakeDOMTextSnapshotAllowed(bool val);

    // Static utility functions
    static String CreateMarkupWithoutChildren(Node* node);

    static Page* localFrameToPage(LocalFrame* frame);
    static WebTaskRunner* getTimerTaskRunner();

    static double secondsToMilliseconds(double timestampSeconds);
    static double getCurrentTimeMs();
    static double getCurrentTimeSeconds();

    static const KURL& getCurrentURL(LocalFrame* frame); 
    static const KURL& getCurrentURL(Document* doc); 
    static const KURL& getCurrentURL(ExecutionContext* context);
    static const CString getCurrentURLCString(LocalFrame* frame);
    static CString toCString(const KURL& url);  
    static CString toCString(const String& str); 
    static CString toCString(const String* str);
    static const char* toCharPtr(const WebInputEvent& event);

    static Element* eventTarget(LocalFrame* frame, const WebInputEvent& inputEvent);
    static bool s_isBlockNetworkRequest; //NOTE(Bo): this is a temp solution, will be removed later
    static bool s_isInstallDomTimer;
    static bool s_isRunWebWorker;
    static bool s_isSendXMLRequest;
    static bool s_isSetWeakCallback;
    static bool s_isOutputBackgroundImage;

private:

    static Element* keyEventTarget(LocalFrame* frame, const WebInputEvent& inputEvent);
    static Element* mouseEventTarget(LocalFrame* frame, const WebInputEvent& inputEvent);
    static void mouseEventHitTestResult(LocalFrame* frame, IntPoint point, HitTestResult& htr);
    
    static bool s_isJavaScriptAllowed;
    static bool s_isAsynchronousParsingAllowed;
    static bool s_isTakeDOMTextSnapshotAllowed;
    

}; // class Forensics

} // namespace blink

#endif // Forensics_h
