/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/

#ifndef ForensicImageDataStore_h
#define ForensicImageDataStore_h

#include "wtf/ThreadSafeRefCounted.h"
#include "core/dom/Node.h"
#include "wtf/PassOwnPtr.h"
#include "wtf/PassRefPtr.h"
#include "platform/SharedBuffer.h"


namespace blink {


class ForensicImageDataStore : public ThreadSafeRefCounted<ForensicImageDataStore> {

public:
    static PassRefPtr<ForensicImageDataStore> create(Document* document, Node* node);

    ~ForensicImageDataStore(){};
    PassRefPtr<SharedBuffer> getImageData();
    const KURL& getImageSrc();    

private:
    ForensicImageDataStore(Document* document, Node* node);
    RefPtr<SharedBuffer> m_imageData;
    KURL m_imageSrc;



}; // class ForensicImageDataStore

} // namespace blink

#endif /* ForensicImageDataStore_h */