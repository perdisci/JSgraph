#include "config.h"
#include "core/inspector/forensics/ForensicXHRDataStore.h"
#include "platform/Logging.h"



namespace blink {

PassRefPtr<ForensicXHRDataStore> ForensicXHRDataStore::create(bool data){
	
	return adoptRef(new ForensicXHRDataStore(data));
}

PassRefPtr<ForensicXHRDataStore> ForensicXHRDataStore::create(int data){
	
	return adoptRef(new ForensicXHRDataStore(data));
}

PassRefPtr<ForensicXHRDataStore> ForensicXHRDataStore::create(ScriptString data){
	return adoptRef(new ForensicXHRDataStore(data));
}

bool ForensicXHRDataStore::getBoolDataStore(){
	return m_boolDataStore;
}

int ForensicXHRDataStore::getIntDataStore(){
	return m_intDataStore;
}

ScriptString ForensicXHRDataStore::getScriptStringDataStore(){
	return m_scriptStringDataStore;
}

ForensicXHRDataStore::ForensicXHRDataStore(bool data)
: m_boolDataStore(data)
, m_intDataStore(0)
, m_scriptStringDataStore(ScriptString())
{
	WTF_LOG(Forensics,"ForensicXHRDataStore::ForensicXHRDataStore: recorded. data: %d. ", data);

}

ForensicXHRDataStore::ForensicXHRDataStore(int data)
: m_boolDataStore(false)
, m_intDataStore(data)
, m_scriptStringDataStore(ScriptString())
{
	WTF_LOG(Forensics,"ForensicXHRDataStore::ForensicXHRDataStore: recorded. data: %d. ", data);

}

ForensicXHRDataStore::ForensicXHRDataStore(ScriptString data)
: m_boolDataStore(false)
, m_intDataStore(0)
, m_scriptStringDataStore(data)
{
	
}

} // namespace blink