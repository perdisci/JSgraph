/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/

#ifndef ForensicDataStore_h
#define ForensicDataStore_h

#include "wtf/Vector.h"
#include "wtf/HashMap.h"
#include "wtf/PassRefPtr.h"
#include "wtf/RefCounted.h"
#include "core/inspector/forensics/ForensicEvent.h"
#include "core/inspector/forensics/ForensicDOMEvent.h"
#include "core/inspector/forensics/ForensicImageDataStore.h"
#include "core/inspector/forensics/ForensicXHRDataStore.h"
#include "core/inspector/forensics/ForensicCSSDataStore.h"
#include "wtf/LinkedStack.h"
#include "public/platform/Platform.h"


namespace blink {

class LocalFrame;
class WebInputEvent;
class Document;
class Node;
class EventTarget;
class EventListener;
class Event;
class ExecutionContext;
class ScriptSourceCode;
class ScheduledAction;
class FrameRequestCallback;


class ForensicDataStore : public RefCounted<ForensicDataStore> {

public:

    static PassRefPtr<ForensicDataStore> create();
    static bool isWillSkipForensicDOMEvent(PassRefPtr<ForensicDOMEvent> event);

    ~ForensicDataStore(){};

    // records an event
    void setBlinkPlatform(Platform* blinkPlatform){m_blinkPlatform=blinkPlatform;}
    void recordInputEvent(LocalFrame* mainFrame, const WebInputEvent& inputEvent);
    void recordInsertDOMNodeEvent(Document* doc, Node* node);
    void recordPageLoadEvent(LocalFrame* frame, const KURL& requestURL);
    void recordImage(Document* doc,Node* node);
    void recordFireEventListenerEvent(LocalFrame* frame, EventTarget* eventTarget, Event* event, EventListener* listener, bool useCapture, bool isRecordEventInJS);
    void recordAddEventListenerEvent(EventTarget* eventTarget, EventListener* listener);
    void recordInstallDOMTimerEvent(ExecutionContext* context, ScheduledAction* action, int timeoutID);
    void recordFireDOMTimerEvent(LocalFrame* frame, ExecutionContext* context, ScheduledAction* action, int timeoutID,  bool singleShot);
    void recordXHRDataStore(PassRefPtr<ForensicXHRDataStore> data);
    void recordEvaluateScriptInMainWorldEvent(ExecutionContext* context, const ScriptSourceCode&  sourceCode, int accessControlStatus, bool policy, bool isRecordEventInJS);
    void recordChildFrame(LocalFrame* frame, const KURL& url);
    void recordCookieDataStore(const String& cookieString, const String& exceptionStateString);
    void recordSetCookieDataStore(const String& exceptionStateString);
    void recordDocumentWriteDataStore(bool hasInsertionPoint);
    void recordCharacterDataPaserAppendDataEvent(LocalFrame* frame, Node* node, const String& data);
    void recordDocumentReadyState(const String& readyState);
    void recordCSSDataStore(PassRefPtr<ForensicCSSDataStore> data);
    void recordEventTimeStampDataStore(double timestamp);
    void recordRegisterFrameRequestCallbackEvent(FrameRequestCallback* callback, int id);
    void recordExecuteFrameRequestCallbackEvent(ExecutionContext* context,FrameRequestCallback* callback, int id, double highResNowMs);
    void recordDynamicScriptExecutionCount(int dynamicScriptExecutionCount, bool isDumpCountStack);
    double nextEventTimeStampDataStore();
    void nextCookieDataStore(String& cookieString, String& exceptionStateString);
    String nextSetCookieDataStore();
    String nextDocumentReadyState();
    void nextFrameRequestCallback(long& callback, int& id);
    bool nextHasInsertionPoints();
    bool isInProgressingOfReplayingIframe();
    PassRefPtr<ForensicImageDataStore> getImage(Node* node);
    // Vector<RefPtr<ForensicEvent> >& allForensicEvents();
    PassRefPtr<ForensicEvent> nextAvailableForensicEvent();
    PassRefPtr<ForensicDOMEvent> findNextDoctypeForensicDOMEvent();
    PassRefPtr<ForensicDOMEvent> findNextHtmlForensicDOMEvent();
    PassRefPtr<ForensicDOMEvent> findNextHeadForensicDOMEvent();
    PassRefPtr<ForensicDOMEvent> findNextBodyForensicDOMEvent();
    PassRefPtr<ForensicDOMEvent> nextAvailableForensicDOMEvent();
    PassRefPtr<ForensicDOMEvent> currentAvailableForensicDOMEvent();
    PassRefPtr<ForensicXHRDataStore> nextXHRDataStore();
    PassRefPtr<ForensicCSSDataStore> nextCSSDataStore();
    void nextEventListenerInfo(long &eventTargetIndex, long &eventListenerIndex);
    void nextDomTimerInfo(long &domTimerContextIndex, long &domTimerActionIndex, int &domTimerTimeoutID);
    long nextFrame();
    int nextDynamicScriptExecutionCount();
    
    // RefPtr<ForensicEvent> lastConsumedForensicEvent();

    // marks all consumed events as available
    // the next available event will be the first recorded event
    // the last consumed event will be null
    // void resetConsumedForensicEvents();

private:
    ForensicDataStore();

    void appendForensicEvent(PassRefPtr<ForensicEvent> event);
    void appendForensicDOMEvent(PassRefPtr<ForensicDOMEvent> event);

    // Web API data
    Vector<RefPtr<ForensicEvent> > m_events;
    Vector<long> m_frames;
    Vector<long> m_eventTargets;
    Vector<long> m_eventListeners;
    Vector<long> m_domTimerContexts;
	Vector<long> m_domTimerActions;
	Vector<int> m_domTimerTimeoutIDs;
	Vector<long> m_frameRequestCallbacks;
	Vector<int> m_frameRequestCallbackIds;
	Vector<double> m_eventTimeStamps;
	Vector<String> m_cookieStrings;
	Vector<String> m_exceptionStateStringsCookie;
	Vector<String> m_exceptionStateStringsSetCookie;
	Vector<String> m_documentReadyState;
	Vector<RefPtr<ForensicXHRDataStore>> m_xHRDataStore;
	Vector<RefPtr<ForensicCSSDataStore>> m_cSSDataStore;
	Vector<bool> m_hasInsertionPoints;
	Vector<int> m_dynamicScriptExecutionCounts;
    HashMap<String, Vector<RefPtr<ForensicDOMEvent>>> m_domEvents;
    HashMap<long, RefPtr<ForensicImageDataStore>> m_imageDataStore;
    Vector<RefPtr<ForensicDOMEvent>> m_domEventList;
    LinkedStack<int> m_tempDynamicScriptExecutionCountStack;
    size_t m_nextEventIndex;
    size_t m_currentDOMEventIndex;
    size_t m_lastEventIndex;
    size_t m_nextEventListenerIndex; 
    size_t m_nextDomTimerIndex;
    size_t m_nextXHRIndex;
    size_t m_nextFrameIndex;
    size_t m_cookieStringIndex;
    size_t m_exceptionStateStringsSetCookieIndex;
    size_t m_hasInsertionPointIndex;
    size_t m_documentReadyStateIndex;
    size_t m_nextCSSIndex;
    size_t m_nextEventTimeStampIndex;
    size_t m_nextFrameRequestCallbackIndex;
    size_t m_nextDynamicScriptExecutionCountIndex;
    bool m_nextStarted;
    Platform* m_blinkPlatform;

}; // class ForensicDataStore

} // namespace blink

#endif // ForensicDataStore_h
