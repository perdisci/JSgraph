/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/

#include "config.h"
#include "core/inspector/forensics/Forensics.h"
#include "core/inspector/forensics/ForensicReplayEngine.h"
#include "bindings/core/v8/ScriptController.h"
#include "public/web/WebInputEvent.h"
#include "public/platform/WebTraceLocation.h"
#include "core/dom/Document.h"
#include "core/dom/Node.h"
#include "core/loader/FrameLoadRequest.h"
#include "platform/network/ResourceRequest.h"
#include "core/fetch/MemoryCache.h"
#include "core/fetch/ResourceFetcher.h"
#include "core/editing/serializers/Serialization.h"
#include "core/html/HTMLImageElement.h"
#include "core/fetch/ImageResource.h"
#include "platform/graphics/Image.h"
#include "platform/graphics/BitmapImage.h"
#include "bindings/core/v8/ScriptEventListener.h"
#include "core/events/Event.h"
#include "core/events/EventTarget.h"
#include "bindings/core/v8/ScheduledAction.h"
#include "core/dom/ExecutionContext.h"
#include "platform/text/SegmentedString.h"
#include "core/fetch/SubstituteData.h"
#include "core/loader/FrameLoadRequest.h"
#include "core/dom/FrameRequestCallback.h"

namespace blink {

PassRefPtr<ForensicReplayEngine> ForensicReplayEngine::create(LocalFrame* mainFrame, InspectorPageAgent* pageAgent, PassRefPtr<ForensicDataStore> dataStore, double recordingStartTime) {
    return adoptRef(new ForensicReplayEngine(mainFrame, pageAgent, dataStore, recordingStartTime));
}

ForensicReplayEngine::ForensicReplayEngine(LocalFrame* mainFrame, InspectorPageAgent* pageAgent, PassRefPtr<ForensicDataStore> dataStore, double recordingStartTime) 
    : m_mainFrame(mainFrame)
    , m_pageAgent(pageAgent)
    , m_dataStore(dataStore) 
    , m_recordingStartTime(recordingStartTime)
    , m_lastInjectedNode(nullptr)
    , m_isFinalDivInjection(false)
{
}

void ForensicReplayEngine::startReplay() {
    //To be released
}

void ForensicReplayEngine::handledInputEvent(LocalFrame* frame, const WebInputEvent& event) {
    //To be released
}

String ForensicReplayEngine::getFormatedString(String &currenNodeSource){
	//To be released
	return String();
}

bool ForensicReplayEngine::isLastDOMEventReplayComplied(const String &currentNodeSource, Node* node){
    //To be released
    return false;   
}

void ForensicReplayEngine::handleInsertDOMNodeEvent(LocalFrame* frame, Node* node){
    //To be released
}

void ForensicReplayEngine::handleEvaluateScriptInMainWorldEvent(LocalFrame* frame){
	//To be released
}
void ForensicReplayEngine::handleFireEventListenerEvent(LocalFrame* frame){
	//To be released
}
void ForensicReplayEngine::handleDOMTimerEvent(LocalFrame* frame){
	//To be released
}
void ForensicReplayEngine::handleExecuteFrameRequestCallbackEvent(LocalFrame* frame){
	//To be released
}
void ForensicReplayEngine::handleCharacterDataPaserAppendDataEvent(LocalFrame* frame, Node* node, const String& data){
	//To be released
}

void ForensicReplayEngine::handleDynamicScriptExecutionStartForensics(LocalFrame* frame){
	//To be released
}

bool ForensicReplayEngine::replayNextDOMEvent(Document* doc){
    //To be released
    return 0;
}

LocalFrame* ForensicReplayEngine::getMatchedLocalFrame(Frame* frame){

	//To be released
	
}

void ForensicReplayEngine::replayNextEvent(bool delayed /* default = true */) {
    //To be released
}

double ForensicReplayEngine::computeEventInjectionDelay(double nextEventRecordTime) {
    //To be released
    return 0;
}

void ForensicReplayEngine::clearLastInjectedNode(){
	//To be released
}

void ForensicReplayEngine::clearNodeMap(){
	//To be released
}

void ForensicReplayEngine::clearCallbackMaps(){
	//To be released
}

void ForensicReplayEngine::clearFrameMap(){
	//To be released
}

// static
void ForensicReplayEngine::loadPage(LocalFrame* frame, const KURL& url) {
    FrameLoadRequest request(frame->document(), ResourceRequest(frame->document()->completeURL(url)));
    frame->loader().load(request);
}

// static
void ForensicReplayEngine::cleanMemoryCache(LocalFrame* frame) {
    memoryCache()->evictResources();
    for (LocalFrame* f = frame; f != nullptr; f = toLocalFrame(f->tree().traverseNext()))
        f->document()->fetcher()->garbageCollectDocumentResources();
}

// static
void ForensicReplayEngine::doCleanCacheAndReloadPage(LocalFrame* frame, const KURL& url) {
    // FIXME(Roberto): loading "about:blank" is likely redundant, but it's there to make sure the page is completely reloaded
    //loadPage(frame, KURL(ParsedURLString, "about:blank"));
    cleanMemoryCache(frame);
    loadPage(frame, url);
}

void ForensicReplayEngine::handleAddEventListener(EventTarget* eventTarget, PassRefPtr<EventListener> listener, bool useCapture){
	//To be released
}

int ForensicReplayEngine::handleInstallDomTimer(ExecutionContext* context, PassOwnPtr<ScheduledAction> action){
	//To be released
	return 0;
}

int ForensicReplayEngine::handleGetXHRDataResponseTypeCodeForensics(){
	//To be released
	return 0;
}

int ForensicReplayEngine::handleGetXHRDataStatusForensics(){
	//To be released
	return 0;
}

int ForensicReplayEngine::handleGetXHRDataReadyStateForensics(){
	//To be released
	return 0;
}

ScriptString ForensicReplayEngine::handleGetXHRDataResponseTextForensics(){
	//To be released
	return ScriptString();
}

bool ForensicReplayEngine::handleGetXHRDataOpenForensics(){
	//To be released
	return false;
}

String ForensicReplayEngine::handleGetCSSItemForensics(unsigned i){
	//To be released
	return String();
}

unsigned ForensicReplayEngine::handleGetCSSLengthForensics(){
	//To be released
	return 0;
}


String ForensicReplayEngine::handleGetCSSGetPropertyValueForensics(){
	//To be released
	return String();
}

String ForensicReplayEngine::handleGetCSSGetPropertyPriorityForensics(){
	//To be released
	return String();
}

void ForensicReplayEngine::handleGetCookieForensics(String& cookieString, String& exceptionStateString){
	//To be released
}
void ForensicReplayEngine::handleGetSetCookieForensics(String& exceptionStateString){
	//To be released
}

double ForensicReplayEngine::handleGetEventTimeStampForensics(){
	//To be released
	return 0;
}

void ForensicReplayEngine::handleDocumentReadyStateReplaying(String& readyState){
	//To be released
}

void ForensicReplayEngine::handleDocumentWriteStart(bool& hasInsertionPoint, const SegmentedString& text){
	//To be released
}

void ForensicReplayEngine::handleRegisterFrameRequestCallback(FrameRequestCallback* callback, int& id){
	//To be released
}

void ForensicReplayEngine::handleCreateChildFrameLoader(LocalFrame* frame, const KURL& url){
	//To be released
	
}

void ForensicReplayEngine::loadNextRecordedPagewithURL(LocalFrame* frame, const KURL& url){
    //To be released
}

void ForensicReplayEngine::handleDidStartProvisionalLoad(LocalFrame* frame){
	//To be released
}

String ForensicReplayEngine::getNextPageStarter(){
	//To be released
	return String();
}


} // namespace blink
