/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/
#include "base/synchronization/lock.h"
#include "base/files/file.h"

template <typename T> struct DefaultSingletonTraits;
class LogFd {
   public:
    static LogFd* GetInstance(); 
    base::File file;
    double t;

    LogFd(); 
    ~LogFd(); 
    //base::Lock ss_lock;
   private:
    friend struct DefaultSingletonTraits<LogFd>;

    DISALLOW_COPY_AND_ASSIGN(LogFd);
  };
