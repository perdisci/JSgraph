/*
Copyright (C) 2018 University of Georgia. All rights reserved.

This file is subject to the terms and conditions defined at
https://github.com/perdisci/JSgraph/blob/master/LICENSE.txt

*/
#include "base/memory/singleton.h"
#include "content/public/renderer/log_fd.h"


LogFd* LogFd::GetInstance() {
    return base::Singleton<LogFd>::get();
}

LogFd::LogFd() {
}

LogFd::~LogFd() {
}
