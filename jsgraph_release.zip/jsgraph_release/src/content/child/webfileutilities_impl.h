// Copyright 2014 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef CONTENT_CHILD_WEBFILEUTILITIES_IMPL_H_
#define CONTENT_CHILD_WEBFILEUTILITIES_IMPL_H_

#include "content/common/content_export.h"
#include "third_party/WebKit/public/platform/WebFileInfo.h"
#include "third_party/WebKit/public/platform/WebFileUtilities.h"

#include "base/bind.h"
#include "base/single_thread_task_runner.h"
#include "base/memory/scoped_ptr.h"
#include "base/threading/thread.h"


namespace content {

class CONTENT_EXPORT WebFileUtilitiesImpl
    : NON_EXPORTED_BASE(public blink::WebFileUtilities) {
 public:
  WebFileUtilitiesImpl();
  virtual ~WebFileUtilitiesImpl();

  // WebFileUtilities methods:
  bool getFileInfo(const blink::WebString& path,
                   blink::WebFileInfo& result) override;
  blink::WebString directoryName(const blink::WebString& path) override;
  blink::WebString baseName(const blink::WebString& path) override;
  blink::WebURL filePathToURL(const blink::WebString& path) override;

  void set_sandbox_enabled(bool sandbox_enabled) {
    sandbox_enabled_ = sandbox_enabled;
  }

  //Phani
  void tab_log(const char* format, ...) override;
  //Phani
  /*
  void tab_log_combine(const std::string& s1="", const std::string& s2="", 
    	const std::string& s3="", const std::string& s4="", const std::string& s5="",
    	const std::string& s6="", const std::string& s7="", const std::string& s8="",
    	const std::string& s9="", const std::string& s10="", const std::string& s11="",
    	const std::string& s12="", const std::string& s13="") override;
  */
  
	virtual void tab_log_combine(const std::string& s1, const std::string& s2, 
		const std::string& s3, const std::string& s4, const std::string& s5,
		const std::string& s6, const std::string& s7, const std::string& s8,
		const std::string& s9, const std::string& s10, const std::string& s11,
		const std::string& s12, const std::string& s13) override;
	virtual void tab_log_combine(const std::string& s1, const std::string& s2, 
		const std::string& s3, const std::string& s4, const std::string& s5,
		const std::string& s6, const std::string& s7, const std::string& s8,
		const std::string& s9, const std::string& s10, const std::string& s11,
		const std::string& s12)override;
	virtual void tab_log_combine(const std::string& s1, const std::string& s2, 
		const std::string& s3, const std::string& s4, const std::string& s5,
		const std::string& s6, const std::string& s7, const std::string& s8,
		const std::string& s9, const std::string& s10)override;
	virtual void tab_log_combine(const std::string& s1, const std::string& s2, 
		const std::string& s3, const std::string& s4, const std::string& s5,
		const std::string& s6, const std::string& s7, const std::string& s8)override;
	virtual void tab_log_combine(const std::string& s1, const std::string& s2, 
		const std::string& s3, const std::string& s4, const std::string& s5,
		const std::string& s6)override;
	virtual void tab_log_combine(const std::string& s1, const std::string& s2, 
		const std::string& s3, const std::string& s4)override;
	virtual void tab_log_combine(const std::string& s1, const std::string& s2, 
		const std::string& s3)override;
	virtual void tab_log_combine(const std::string& s1, const std::string& s2)override;
	virtual void tab_log_combine(const std::string& s1)override;
	virtual void tab_log_cleanup() override;
 protected:
  bool sandbox_enabled_;
  
 private:
  scoped_refptr<base::SingleThreadTaskRunner> single_thread_task_runner;
  scoped_ptr<base::Thread>  forensics_recording_thread;
  unsigned counter;
  std::vector<std::string> buffer;
};

}  // namespace content

#endif  // CONTENT_CHILD_WEBFILEUTILITIES_IMPL_H_
