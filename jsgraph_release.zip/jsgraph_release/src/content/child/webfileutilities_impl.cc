// Copyright 2014 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "content/child/webfileutilities_impl.h"

#include "base/files/file_path.h"
#include "base/files/file_util.h"
#include "base/logging.h"
#include "base/trace_event/trace_event.h"
#include "content/child/file_info_util.h"
#include "net/base/file_stream.h"
#include "net/base/filename_util.h"
#include "third_party/WebKit/public/platform/WebFileInfo.h"
#include "third_party/WebKit/public/platform/WebString.h"
#include "third_party/WebKit/public/platform/WebURL.h"

#include "base/trace_event/trace_event_argument.h"
//Phani
#include "content/public/renderer/log_fd.h"
#include <stdarg.h>
//Phani



using blink::WebString;

namespace content {

//Bo
void ForesicsRecordingBuffer(LogFd* ins, std::vector<std::string> buffer){
    int counts = 0;
    std::string s = "";
	for (std::vector<std::string>::iterator it = buffer.begin() ; it != buffer.end(); ++it){
	    s += *it;
	    if (counts>100){
			const char * ptr = s.c_str();
			ins->file.WriteAtCurrentPos(ptr, strlen(ptr));
			counts = 0;
			s = "";
		}
		counts++;
	}
	const char * ptr = s.c_str();
	ins->file.WriteAtCurrentPos(ptr, strlen(ptr));
    
}
void ForensicsRecording(LogFd* ins, const char* ptr){
	//TRACE_EVENT0("jsgraph", "JSCapsuleTEST::ForensicsRecording");

    ins->file.WriteAtCurrentPos(ptr, strlen(ptr));
    ins->file.WriteAtCurrentPos("\n",1);

}

void ForesicsRecordingCombine(LogFd* ins, const std::string& s1="", const std::string& s2="", 
    	const std::string& s3="", const std::string& s4="", const std::string& s5="",
    	const std::string& s6="", const std::string& s7="", const std::string& s8="",
    	const std::string& s9="", const std::string& s10=""){
    //TRACE_EVENT0("jsgraph", "JSCapsuleTEST::ForensicsRecordingCombine");
    std::string ptr1 = s1 + s2 + s3 + s4 + s5 + s6 + s7 +s8 + s9 + s10;
    const char * ptr = ptr1.c_str();
    ins->file.WriteAtCurrentPos(ptr, strlen(ptr));
    ins->file.WriteAtCurrentPos("\n",1); 
}
//Bo

WebFileUtilitiesImpl::WebFileUtilitiesImpl()
    : sandbox_enabled_(true) {
    forensics_recording_thread.reset(new base::Thread("forensics_recording_thread"));
  	forensics_recording_thread->Start();
    single_thread_task_runner = forensics_recording_thread->task_runner();
    buffer.clear();
    counter=0;
}

WebFileUtilitiesImpl::~WebFileUtilitiesImpl() {
	fprintf(stderr, "WebFileUtilitiesImpl::~WebFileUtilitiesImpl\n");
    ForesicsRecordingBuffer(LogFd::GetInstance(), buffer);
	forensics_recording_thread->Stop();
}

bool WebFileUtilitiesImpl::getFileInfo(const WebString& path,
                                       blink::WebFileInfo& web_file_info) {
  if (sandbox_enabled_) {
    NOTREACHED();
    return false;
  }
  base::File::Info file_info;
  if (!base::GetFileInfo(base::FilePath::FromUTF16Unsafe(path),
                         reinterpret_cast<base::File::Info*>(&file_info)))
    return false;

  FileInfoToWebFileInfo(file_info, &web_file_info);
  web_file_info.platformPath = path;
  return true;
}

WebString WebFileUtilitiesImpl::directoryName(const WebString& path) {
  return base::FilePath::FromUTF16Unsafe(path).DirName().AsUTF16Unsafe();
}

WebString WebFileUtilitiesImpl::baseName(const WebString& path) {
  return base::FilePath::FromUTF16Unsafe(path).BaseName().AsUTF16Unsafe();
}

blink::WebURL WebFileUtilitiesImpl::filePathToURL(const WebString& path) {
  return net::FilePathToFileURL(base::FilePath::FromUTF16Unsafe(path));
}


//Phani
void WebFileUtilitiesImpl::tab_log(const char* format, ...) {
	TRACE_EVENT0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log");
    va_list args;
    char *ptr;
    va_start(args, format);

    vasprintf(&ptr, format, args);
    
    va_end(args);
    
    single_thread_task_runner->PostTask(FROM_HERE, base::Bind(&ForensicsRecording, LogFd::GetInstance(),std::move(ptr)));
	
}
//Phani

//Bo
void WebFileUtilitiesImpl::tab_log_combine(const std::string& s1, const std::string& s2, 
    	const std::string& s3, const std::string& s4, const std::string& s5,
    	const std::string& s6, const std::string& s7, const std::string& s8,
    	const std::string& s9, const std::string& s10, const std::string& s11,
    	const std::string& s12, const std::string& s13){
    //int length = s1.length()+s2.length()+s3.length()+s4.length()+s5.length()+s6.length()+s7.length()+s8.length()+s9.length()+s10.length()++s11.length()+s12.length()+s13.length();
    //TRACE_EVENT0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine");
    

	buffer.push_back(s1);
	buffer.push_back(s2);
	buffer.push_back(s3);
	buffer.push_back(s4);
	buffer.push_back(s5);
	buffer.push_back(s6);
	buffer.push_back(s7);
	buffer.push_back(s8);
	buffer.push_back(s9);
	buffer.push_back(s10);
	buffer.push_back(s11);
	buffer.push_back(s12);
	buffer.push_back(s13);
	buffer.push_back("\n");
	counter++;
		
	if (counter>=5000) {
		//TRACE_EVENT_BEGIN0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine_PostTask");
		single_thread_task_runner->PostTask(FROM_HERE, base::Bind(&ForesicsRecordingBuffer, 
    	LogFd::GetInstance(),std::move(buffer)));
    	buffer.clear();
    	counter=0;
	}
    
    //double length = s1.length()+s2.length()+s3.length()+s4.length()+s5.length()+s6.length()+s7.length()+s8.length()+s9.length()+s10.length();
    //base::trace_event::TracedValue* value = new base::trace_event::TracedValue();
	//value->SetDouble("length", length);
    //TRACE_EVENT_BEGIN1("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine","length",length);
    //base::Bind(&ForesicsRecordingCombine, 
    //	LogFd::GetInstance(),s1,s2,s3,s4,s5,s6,s7,s8,s9,s10);
    //TRACE_EVENT_BEGIN0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine1");
    //single_thread_task_runner->PostTask(FROM_HERE, base::Bind(&ForesicsRecordingCombine, 
    //	LogFd::GetInstance(),s1,s2,s3,s4,s5,s6,s7,s8,s9,s10));
    //TRACE_EVENT_END0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine1");
    
}

void WebFileUtilitiesImpl::tab_log_combine(const std::string& s1, const std::string& s2, 
    	const std::string& s3, const std::string& s4, const std::string& s5,
    	const std::string& s6, const std::string& s7, const std::string& s8,
    	const std::string& s9, const std::string& s10, const std::string& s11,
    	const std::string& s12){
    //int length = s1.length()+s2.length()+s3.length()+s4.length()+s5.length()+s6.length()+s7.length()+s8.length()+s9.length()+s10.length()++s11.length()+s12.length()+s13.length();
    //TRACE_EVENT0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine");
    

	buffer.push_back(s1);
	buffer.push_back(s2);
	buffer.push_back(s3);
	buffer.push_back(s4);
	buffer.push_back(s5);
	buffer.push_back(s6);
	buffer.push_back(s7);
	buffer.push_back(s8);
	buffer.push_back(s9);
	buffer.push_back(s10);
	buffer.push_back(s11);
	buffer.push_back(s12);
	buffer.push_back("\n");
	counter++;

    if (counter>=5000) {
		//TRACE_EVENT_BEGIN0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine_PostTask");
		single_thread_task_runner->PostTask(FROM_HERE, base::Bind(&ForesicsRecordingBuffer, 
    	LogFd::GetInstance(),std::move(buffer)));
    	buffer.clear();
    	counter=0;
	}
    
}

void WebFileUtilitiesImpl::tab_log_combine(const std::string& s1, const std::string& s2, 
    	const std::string& s3, const std::string& s4, const std::string& s5,
    	const std::string& s6, const std::string& s7, const std::string& s8,
    	const std::string& s9, const std::string& s10){
    //int length = s1.length()+s2.length()+s3.length()+s4.length()+s5.length()+s6.length()+s7.length()+s8.length()+s9.length()+s10.length()++s11.length()+s12.length()+s13.length();
    //TRACE_EVENT0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine");
    

	buffer.push_back(s1);
	buffer.push_back(s2);
	buffer.push_back(s3);
	buffer.push_back(s4);
	buffer.push_back(s5);
	buffer.push_back(s6);
	buffer.push_back(s7);
	buffer.push_back(s8);
	buffer.push_back(s9);
	buffer.push_back(s10);
	buffer.push_back("\n");
	counter++;

    if (counter>=5000) {
		//TRACE_EVENT_BEGIN0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine_PostTask");
		single_thread_task_runner->PostTask(FROM_HERE, base::Bind(&ForesicsRecordingBuffer, 
    	LogFd::GetInstance(),std::move(buffer)));
    	buffer.clear();
    	counter=0;
	}
    
}

void WebFileUtilitiesImpl::tab_log_combine(const std::string& s1, const std::string& s2, 
    	const std::string& s3, const std::string& s4, const std::string& s5,
    	const std::string& s6, const std::string& s7, const std::string& s8){
    //int length = s1.length()+s2.length()+s3.length()+s4.length()+s5.length()+s6.length()+s7.length()+s8.length()+s9.length()+s10.length()++s11.length()+s12.length()+s13.length();
    //TRACE_EVENT0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine");
    

	buffer.push_back(s1);
	buffer.push_back(s2);
	buffer.push_back(s3);
	buffer.push_back(s4);
	buffer.push_back(s5);
	buffer.push_back(s6);
	buffer.push_back(s7);
	buffer.push_back(s8);
	buffer.push_back("\n");
	counter++;

    if (counter>=5000) {
		//TRACE_EVENT_BEGIN0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine_PostTask");
		single_thread_task_runner->PostTask(FROM_HERE, base::Bind(&ForesicsRecordingBuffer, 
    	LogFd::GetInstance(),std::move(buffer)));
    	buffer.clear();
    	counter=0;
	}
    
}

void WebFileUtilitiesImpl::tab_log_combine(const std::string& s1, const std::string& s2, 
    	const std::string& s3, const std::string& s4, const std::string& s5,
    	const std::string& s6){
    //int length = s1.length()+s2.length()+s3.length()+s4.length()+s5.length()+s6.length()+s7.length()+s8.length()+s9.length()+s10.length()++s11.length()+s12.length()+s13.length();
    //TRACE_EVENT0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine");
    

	buffer.push_back(s1);
	buffer.push_back(s2);
	buffer.push_back(s3);
	buffer.push_back(s4);
	buffer.push_back(s5);
	buffer.push_back(s6);
	buffer.push_back("\n");
	counter++;

    if (counter>=5000) {
		//TRACE_EVENT_BEGIN0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine_PostTask");
		single_thread_task_runner->PostTask(FROM_HERE, base::Bind(&ForesicsRecordingBuffer, 
    	LogFd::GetInstance(),std::move(buffer)));
    	buffer.clear();
    	counter=0;
	}
    
}

void WebFileUtilitiesImpl::tab_log_combine(const std::string& s1, const std::string& s2, 
    	const std::string& s3, const std::string& s4){
    //int length = s1.length()+s2.length()+s3.length()+s4.length()+s5.length()+s6.length()+s7.length()+s8.length()+s9.length()+s10.length()++s11.length()+s12.length()+s13.length();
    //TRACE_EVENT0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine");
    

	buffer.push_back(s1);
	buffer.push_back(s2);
	buffer.push_back(s3);
	buffer.push_back(s4);
	buffer.push_back("\n");
	counter++;

    if (counter>=5000) {
		//TRACE_EVENT_BEGIN0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine_PostTask");
		single_thread_task_runner->PostTask(FROM_HERE, base::Bind(&ForesicsRecordingBuffer, 
    	LogFd::GetInstance(),std::move(buffer)));
    	buffer.clear();
    	counter=0;
	}
    
}

void WebFileUtilitiesImpl::tab_log_combine(const std::string& s1, const std::string& s2, 
    	const std::string& s3){
    //int length = s1.length()+s2.length()+s3.length()+s4.length()+s5.length()+s6.length()+s7.length()+s8.length()+s9.length()+s10.length()++s11.length()+s12.length()+s13.length();
    //TRACE_EVENT0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine");
    

	buffer.push_back(s1);
	buffer.push_back(s2);
	buffer.push_back(s3);
	buffer.push_back("\n");
	counter++;

    if (counter>=5000) {
		//TRACE_EVENT_BEGIN0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine_PostTask");
		single_thread_task_runner->PostTask(FROM_HERE, base::Bind(&ForesicsRecordingBuffer, 
    	LogFd::GetInstance(),std::move(buffer)));
    	buffer.clear();
    	counter=0;
	}
    
}

void WebFileUtilitiesImpl::tab_log_combine(const std::string& s1, const std::string& s2){
    //int length = s1.length()+s2.length()+s3.length()+s4.length()+s5.length()+s6.length()+s7.length()+s8.length()+s9.length()+s10.length()++s11.length()+s12.length()+s13.length();
    //TRACE_EVENT0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine");
    

	buffer.push_back(s1);
	buffer.push_back(s2);
	buffer.push_back("\n");
	counter++;

    if (counter>=5000) {
		//TRACE_EVENT_BEGIN0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine_PostTask");
		single_thread_task_runner->PostTask(FROM_HERE, base::Bind(&ForesicsRecordingBuffer, 
    	LogFd::GetInstance(),std::move(buffer)));
    	buffer.clear();
    	counter=0;
	}
    
}

void WebFileUtilitiesImpl::tab_log_combine(const std::string& s1){
    //int length = s1.length()+s2.length()+s3.length()+s4.length()+s5.length()+s6.length()+s7.length()+s8.length()+s9.length()+s10.length()++s11.length()+s12.length()+s13.length();
    //TRACE_EVENT0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine");
    

		buffer.push_back(s1);
		buffer.push_back("\n");
		counter++;

    if (counter>=5000) {
		//TRACE_EVENT_BEGIN0("jsgraph", "JSCapsule::WebFileUtilitiesImpl::tab_log_combine_PostTask");
		single_thread_task_runner->PostTask(FROM_HERE, base::Bind(&ForesicsRecordingBuffer, 
    	LogFd::GetInstance(),std::move(buffer)));
    	buffer.clear();
    	counter=0;
	}
    
}

void WebFileUtilitiesImpl::tab_log_cleanup(){
	ForesicsRecordingBuffer(LogFd::GetInstance(), std::move(buffer));
	buffer.clear();
	counter=0;
}
//Bo
}  // namespace content
